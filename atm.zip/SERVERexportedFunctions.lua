------------------------------------------------------------------------------------
--  RIGHTS:      All rights reserved by developers
--  FILE:        ATMsystem/SERVERexportedFunctions.lua
--  PURPOSE:     ATM System v2.0
--  DEVELOPER:   A!ExXx AKA iAnnas
------------------------------------------------------------------------------------

function getBankID( bankMarker )

	if type( bankMarker ) == "userdata" and getElementType( bankMarker ) == "marker" then

		for k, v in pairs( banksInfo ) do

			if banksInfo[ k ].marker == bankMarker then

				return k

			end

		end

	elseif type( bankMarker ) == "string" then

		for k, v in pairs( banksInfo ) do

			if banksInfo[ k ].name == bankMarker then

				return k

			end

		end

	end

	return false

end





function getBankPosition( bank )

	if type( bank ) == "userdata" and getElementType( bank ) == "marker" then

		for k, v in pairs( banksInfo ) do

			if banksInfo[ k ].marker == bank then

				return getElementPosition( bank )

			end

		end

	elseif type( bank ) == "string" then

		for k, v in pairs( banksInfo ) do

			if banksInfo[ k ].name == bank then

				return getElementPosition( banksInfo[ k ].marker );

			end

		end

	elseif type( bank ) == "integer" then

		local banks = countBanks( )

		if bank > 0 and bank <= banks then

			if banksInfo[ bank ].marker then

				return getElementPosition( banksInfo[ bank ].marker )

			end

		end

	end

	return false

end



function getBankMarker( bankID )

	if type( bankID ) == "number" and bankID <= countBanks( ) and bankID > 0 then

		return banksInfo[ bankID ].marker

	elseif type( bankID ) == "string" then

		for k, v in pairs( banksInfo ) do

			if banksInfo[ k ].name == bankID then

				return banksInfo[ k ].marker

			end

		end

	end

	return false

end

function getBankName( bankID )

	if type( bankID ) == "number" then

		if bankID <= countBanks( ) and bankID > 0 then

			return banksInfo[ bankID ].name

		end

	elseif type( bankID ) == "userdata" and getElementType( bankID ) == "marker" then

		for i = 0, countBanks() do

			if banksInfo[ i + 1 ].marker == bankID then

				return banksInfo[ i + 1 ].name

			end

		end

	end

	return false

end

function setBankName( bankID, newname )

	if type( bankID ) == "number" and type( newname ) == "string" then

		if bankID <= countBanks( ) and bankID > 0 then

			banksInfo[ bankID ].name = newname

			return true

		end

	elseif ( type( bankID ) == "userdata" and type( newname ) == "string" and getElementType( bankID ) == "marker" ) or

		( type( bankID ) == "string" and type( newname ) == "string" ) then

		bankID = getBankID( bankID )

		if bankID then

			banksInfo[ bankID ].name = newname

			return true

		end

	end

	return false

end


function getBankMarkers( )

	local markers = { }

	for k, v in pairs( banksInfo ) do

		table.insert( markers, banksInfo[ k ].marker )

	end

	if #markers > 0 then

		return markers

	end

	return false

end


function getBankEntranceMarker( bankID )

	local banks = countBanks( )

	if type( bankID ) == "number" and bankID <= banks and bankID > 0 then

		return banksInfo[ bankID ].entrance.marker

	elseif ( type( bankID ) == "userdata" and getElementType( bankID ) == "marker" ) or ( type( bankID ) == "string" ) then

		bankID = getBankID( bankID )

		if bankID then

			if banksInfo[ bankID ].marker and banksInfo[ bankID ].entrance then

				return banksInfo[ bankID ].entrance.marker

			end

		end

	end

	return false

end

function getBankExitMarker( bankID )

	local banks = countBanks( )

	if type( bankID ) == "number" and bankID <= banks and bankID > 0 then

		return banksInfo[ bankID ]._exit.marker

	elseif ( type( bankID ) == "userdata" and getElementType( bankID ) == "marker" ) or ( type( bankID ) == "string" ) then

		bankID = getBankID( bankID )

		if bankID then

			if banksInfo[ bankID ].marker and banksInfo[ bankID ]._exit then

				return banksInfo[ bankID ]._exit.marker

			end

		end

	end

	return false

end

function countBanks( )

	local banks_num = 0

	for k, v in pairs( banksInfo ) do

		banks_num = banks_num + 1

	end

	return banks_num

end


function getBankAccountBalance( accountName, SQLdata )

	if isElement( accountName ) and getElementType( accountName ) == "player" then

		local account = getPlayerAccount( accountName );

		return tonumber( getAccountData( account, "cstbank.balance" ) );

		--accountName = getPlayerName( accountName )

	elseif type( accountName ) ~= "string" then

		return false

	end

	return false

end

function setBankAccountBalance( accountName, newbalance, SQLdata )

	if type( accountName ) == "userdata" and getElementType( accountName ) == "player" then

		accountName = getPlayerAccount( accountName );

		--accountName = getPlayerName( accountName )

	elseif type( accountName ) ~= "string" then

		return false

	end

	if type( newbalance ) ~= "number" then

		return false

	end

	

	if type( newbalance ) == "number" then

		return setAccountData( accountName, "cstbank.balance", newbalance );

	end

	return false 

end



---------------------------------------



function getPlayersInBank( bankID )

	local players = { }

	

	if type( bankID ) == "number" then

		if bankID <= countBanks( ) and bankID > 0 then

			for k, v in pairs( getElementsByType( "player" ) ) do

				if isPlayerInBank( v ) == banksInfo[ bankID ].marker then

					table.insert( players, v )

				end

			end

			return players

		end

	elseif ( type( bankID ) == "userdata" and getElementType( bankID ) == "marker" ) then

		bankID = getElementColShape( bankID )

		if bankID then

			return getElementsWithinColShape( bankID, "player" )

		end

	elseif type( bakID ) == "string" then

		bankID = getBankMarker( bankID )

		if bankID then

			return getElementsWithinColShape( bankID, "player" )

		end

	end

	return false

end





function getPlayerBank( player )

	return isPlayerInBank( player )

end





function withdrawPlayerMoney( player, amount, SQLdata )

	local accountName

	if type( player ) == "userdata" and getElementType( player ) == "player" and type( amount ) == "number" then

		accountName = getPlayerName( player )

	else

		return false

	end

	

	SQLdata = SQLdata or { ["tab"] = bankSQLInfo.tab, ["balance"] = bankSQLInfo.balance, ["username"] = bankSQLInfo.username }

	local balance

	balance = getBankAccountBalance( accountName, SQLdata )

	if balance then

		if balance - amount >= 0 then

			return setBankAccountBalance( accountName, ( balance - amount ), SQLdata )

		end

	end

	return false

end





function depositPlayerMoney( player, amount, SQLdata )

	local accountName

	if type( player ) == "userdata" and getElementType( player ) == "player" and type( amount ) == "number" then

		accountName = getPlayerName( player )

	else

		return false

	end

	

	SQLdata = SQLdata or { ["tab"] = bankSQLInfo.tab, ["balance"] = bankSQLInfo.balance, ["username"] = bankSQLInfo.username }

	local balance = getBankAccountBalance( accountName, SQLdata )

	if balance then

		if amount <= getPlayerMoney( player ) then

			takePlayerMoney( player, amount )

			return setBankAccountBalance( accountName, ( balance + amount ), SQLdata )

		end

	end

	return false

end





function isPlayerInBank( player, bankID )

	if not bankID then

		for k, v in pairs( banksInfo ) do

			if isPlayerInMarker( player, banksInfo[ k ].marker ) then

				return banksInfo[ k ].marker

			end

		end

	elseif ( type( bankID ) == "userdata" ) and ( isElement( bankID ) ) 

	  and ( getElementType( bankID ) == "marker" ) and isPlayerInMarker( player, bankID ) then

		return bankID

	elseif type( bankID ) == "number" then

		if bankID > 0 and bankID <= countBanks( ) then

			if isPlayerInMarker( player, banksInfo[ bankID ].marker ) then

				return banksInfo[ bankID ].marker

			end

		end

	end

	return false

end



function getPlayerBalance( player )

	if type( player ) == "userdata" and getElementType( player ) == "player" then

		return playersAccoun[ player ].balance

	end

	return false

end



function setPlayerBalance( player, newbalance )

	if type( player ) == "userdata" and getElementType( player ) == "player" and type( newbalance ) == "number" then

		return playersAccoun[ player ]:setBalance( newbalance )

	end

	return false

end



function isPlayerInMarker( player, marker )

	local shape = getElementColShape( marker )

	return isElementWithinColShape( player, shape )

end