------------------------------------------------------------------------------------
--  RIGHTS:      All rights reserved by developers
--  FILE:        ATMsystem/SERVERsendATM.lua
--  PURPOSE:     ATM System v2.0
--  DEVELOPER:   A!ExXx AKA iAnnas
------------------------------------------------------------------------------------

addEvent( "bank_giveMeATMs", true )



addEventHandler( "bank_giveMeATMs", resourceRoot,

	function( )

		local atms = { }

		for k, v in ipairs( banksInfo ) do

			local atm = banksInfo[ k ].ATM;

			if atm then

				table.insert( atms, atm );

			end

		end

		triggerClientEvent( client, "bank_takeATMs", client, atms );

	end

)

function setPIN ( source, cmd, old, pin )

      local oldPw = getElementData( source, "ATMPW")

      if (oldPw) and not (old) then outputChatBox("Please enter New PIN first", source, 255, 0, 0) return end

      if (oldPw and oldPw ~= pin) then outputChatBox("Old Password is wrong, Please try again", source, 255, 0, 0) return end

      if (old == oldPw) then outputChatBox(oldPw.. " is Already your PIN code", source, 255, 255, 0) return end

      if (old ~= oldPw) and (pin == oldPw) then

			local playeraccount = getPlayerAccount(source)

            setElementData( source, "ATMPW", old )

			setAccountData (playeraccount, "pin", old)
			
            outputChatBox("You successfully changed your ATM PIN to: "..old, source, 0, 255, 0)

   end

end

addCommandHandler("setpin", setPIN)

function adminGetPIN ( source, cmd, acc )

	  local account = getAccount(acc)

	  local player = getAccountPlayer(account)

      local oldPw = getElementData( player, "ATMPW")

      if (player) and (oldPw) then

            local pin = getElementData( source, "ATMPW" )

            outputChatBox("Account "..acc.." ATM PIN is: "..pin, source, 0, 255, 0)

   end

end

addCommandHandler("admingetpin", adminGetPIN)

-- SAVE PIN WHEN QUIT

function onPlayerQuit()

	local playeraccount = getPlayerAccount(source)

	if (playeraccount) then

		local pin = getElementData(source, "ATMPW")

		setAccountData (playeraccount, "pin", pin)

	end

end

addEventHandler("onPlayerLogout", getRootElement(), onPlayerQuit)

addEventHandler("onPlayerQuit", getRootElement(), onPlayerQuit)


-- LOAD PIN WHEN LOGIN

local root = getRootElement()

addEventHandler("onPlayerLogin", root,

function()

	local playeraccount = getPlayerAccount ( source )

	if ( playeraccount ) then

		local pin = getAccountData (playeraccount, "pin")

		setElementData (source, "ATMPW", pin)

	end

end)