------------------------------------------------------------------------------------
--  RIGHTS:      All rights reserved by developers
--  FILE:        ATMsystem/CLIENTobjects.lua
--  PURPOSE:     ATM System v2.0
--  DEVELOPER:   A!ExXx AKA iAnnas
------------------------------------------------------------------------------------

-- Here objects near ATM Banks

createObject(2942, 561.79998779297, -1255.5999755859, 16.89999961853, 0 , 0, 186) -- LS Rodeo ATM

createObject(2942, 514.52001953125, -1737.5999755859, 11.39999961853, 0 , 0, 82.000030517578) -- LS Santa Maria Beach ATM

createObject(2942, 1674.6999511719, -1719.8000488281, 13.199999809265, 0 , 0, 0) -- LS Commerce ATM

createObject(2942, 2128.3999023438, -1153.75, 23.60000038147, 0 , 0, 203.25) -- LS Jefferson ATM

createObject(2942, 2404.1000976563, -1954.8000488281, 13.199999809265, 0 , 0, 90) -- LS Willowfield ATM

createObject(2942, 2737.8999023438, -1834.5, 10, 0 , 0, 0) -- LS East Beach ATM

createObject(2942, 1975.0799560547, -2178.1000976563, 13.199999809265, 0 , 0, 0) -- LS Airport ATM

createObject(2942, 1050.3000488281, -1422.9000244141, 13.199999809265, 0 , 0, 90.25) -- LS Market ATM

createObject(2942, 1053.1600341797, -1026.5, 31.700000762939, 0 , 0, 0) -- LS Temple ATM

createObject(2942, 223.14999389648, -188.69999694824, 1.2000000476837, 0 , 0, 90) -- LS Blueberry ATM

createObject(2942, 693.64001464844, -539.29998779297, 16, 0 , 0, 179.75) -- LS Dillimore ATM

createObject(2942, 1380.9000244141, 259.70001220703, 19.200000762939, 0 , 0, 156) -- LS Montgomery ATM

createObject(2942, -1979.6999511719, 239.5, 34.799999237061, 0 , 0, 180) -- SF Doherty ATM

createObject(2942, -2412.8000488281, 997, 44.900001525879, 0 , 0, 0) -- SF Juniper Hollow ATM

createObject(2942, -1649.4000244141, 1213.1999511719, 20.799999237061, 0 , 0, 314) -- SF Downtown ATM

createObject(2942, -2211.5, 117.90000152588, 35, 0 , 0, 0) -- SF Garcia ATM

createObject(2942, -2695.3000488281, 260, 4.3000001907349, 0 , 0, 180) -- SF Ocean Flats ATM

createObject(2942, -2763.1999511719, -359, 6.8000001907349, 0 , 0, 180) -- SF Avispa ATM

createObject(2942, -2512.6000976563, 746.79998779297, 34.700000762939, 0 , 0, 0) -- SF Juniper Hill ATM

createObject(2942, -2492.5, 2358.6999511719, 9.8999996185303, 0 , 0, 90) -- SF Bayside ATM

createObject(2942, -1884.1999511719, 889.40002441406, 34.799999237061, 0 , 0, 270) -- SF Downtown Zip ATM

createObject(2942, -1656.8599853516, -431.79998779297, 13.800000190735, 0 , 0, 134.99996948242) -- SF Airport ATM

createObject(2942, -2126.0600585938, -2442.6000976563, 30.299999237061, 0 , 0, 51) -- SF Angel Pine ATM

createObject(2942, -1061.0999755859, -1212.5, 128.89999389648, 0 , 0, 90) -- SF Farm ATM

createObject(2942, 2208.6999511719, 1300.5, 10.5, 0 , 0, 270) -- LV Camel Toe's ATM

createObject(2942, 2575.6999511719, 2070.6999511719, 10.5, 0 , 0, 90) -- LV Old Strip ATM

createObject(2942, 2183.7800292969, 2483, 10.5, 0 , 0, 180) -- LV Emerald Isle ATM

createObject(2942, 1628.4599609375, 1813.2099609375, 10.470000267029, 0 , 0, 90) -- LV Hospital ATM

createObject(2942, 1117.3000488281, 1382.9000244141, 10.5, 0 , 0, 0) -- LV Blackfield ATM

createObject(2942, 1668.6999511719, 2222.6000976563, 10.5, 0 , 0, 0) -- LV Redsands West ATM

createObject(2942, 1450.2199707031, 2616.6899414063, 11, 0 , 0, 0) -- LV Yellow Bell ATM

createObject(2942, -114.40000152588, 1116.0999755859, 19.39999961853, 0 , 0, 90.75) -- LV Fort Carson ATM

createObject(2942, -1505.5, 2588, 55.5, 0 , 0, 90) -- LV El Quebrados ATM

createObject(2942, 414.79998779297, 2534.1799316406, 16.200000762939, 0 , 0, 0) -- LV Abandoned Airstrip ATM

createObject(2942, -833.59997558594, 1506.6999511719, 19.60000038147, 0 , 0, 270) -- LV Tierra Robada ATM