------------------------------------------------------------------------------------
--  RIGHTS:      All rights reserved by developers
--  FILE:        ATMsystem/SERVERscript.lua
--  PURPOSE:     ATM System v2.0
--  DEVELOPER:   A!ExXx AKA iAnnas
------------------------------------------------------------------------------------

resourceRoot = getResourceRootElement( getThisResource() )

root = getRootElement( )



playersAccount = { }

playerInMarker = { }



table.size = function ( tab )

	local i = 0;

	for k, v in pairs( tab ) do

		i = i + 1;

	end

	return i;

end



function resourceStarted( )

	

    bankInit( )

    executeSQLCreateTable( bankSQLInfo.tab, bankSQLInfo.username.. " TEXT, ".. bankSQLInfo.balance .." INT" )



	for k,v in ipairs( getElementsByType( "player" ) ) do

		local mta_account = getPlayerAccount( v )

		if mta_account and isGuestAccount( mta_account ) ~= true then

			local player_balance = getAccountData( mta_account, "cstbank.balance" );

	        if not player_balance then

                playersAccount[ v ] = Account:new( getAccountName( mta_account ), 0, 1 )

                playerInMarker[ v ] = false

            end

			if player_balance then

				playersAccount[ v ] = Account:open( getAccountName( mta_account ), player_balance )

				playerInMarker[ v ] = false

			end

        else

            playersAccount[ v ] = Account:new( getPlayerName( v ), 0 )

            playerInMarker[ v ] = false

		end

	end

	

end

addEventHandler( "onResourceStart", resourceRoot, resourceStarted )





function resourceStopped( )

	bank_saveAllPlayersMoney()

end

addEventHandler( "onResourceStop", resourceRoot, resourceStopped )



function bank_savePlayerMoney( player, playerAccount )

	if getElementType( player ) == "player" and isGuestAccount( playerAccount ) ~= true then

		setAccountData( playerAccount, "cstbank.balance", tostring( playersAccount[ player ].balance ) );

	end

end



function bank_saveAllPlayersMoney()

	for k, v in ipairs( getElementsByType( "player" ) ) do

		bank_savePlayerMoney( v, getPlayerAccount( v ) )

	end

end



function bank_playerJoined()

	playersAccount[ source ] = Account:new( getPlayerName( source ), 0 )

end

addEventHandler( "onPlayerJoin", root, bank_playerJoined )



function bank_playerQuit()

	local mta_account = getPlayerAccount( source )

	if isGuestAccount( mta_account ) ~= true and getAccountName( mta_account ) == getPlayerName( source ) then

		bank_savePlayerMoney( source, mta_account )

	end

	playersAccount[ source ] = nil

end

addEventHandler( "onPlayerQuit", root, bank_playerQuit )



function bank_playerLogin( oldAccount, currentAccount )

	if isGuestAccount( oldAccount ) == true and getElementType( source ) == "player" then

		local player_balance = getAccountData( currentAccount, "cstbank.balance" );

		if player_balance then

			playersAccount[ source ]:setBalance( tonumber( player_balance ) )

            playersAccount[ source ]:setAccountName( getAccountName( currentAccount ) )

			if isPlayerInBank( source ) then

				triggerClientEvent( source, "bank_updateMyBalance", source, tonumber( player_balance ) )

			end

		else

			playersAccount[ source ] = nil;

			playersAccount[ source ] = Account:new( getAccountName( currentAccount ), 0, true );

		end

	end

end

addEventHandler( "onPlayerLogin", root, bank_playerLogin )



function bank_playerLogout( oldAccount, currentAccount )

	if isGuestAccount( currentAccount ) == true and isGuestAccount( oldAccount ) ~= true and getAccountName( oldAccount ) == playersAccount[ source ]:accountname() then

		bank_savePlayerMoney( source, oldAccount )

		playersAccount[ source ]:setBalance( 0 )

        playersAccount[ source ]:setAccountName( getPlayerName( source ) )

		playerInMarker[ source ] = false

		outputChatBox( "You have successfully logged out. Your bank balance has been saved!", source, 0, 255, 0 )

	end

end

addEventHandler( "onPlayerLogout", root, bank_playerLogout )


function bankbalance(player)

    outputChatBox("Your current balance is $".. tostring(playersAccount[ player ].balance)..".", player, 255, 255, 0)

end

addCommandHandler("bankbalance", bankbalance)


function playerEnterMarker( marker )

	if ( not isPedOnGround ( source ) ) or ( doesPedHaveJetPack ( source ) ) or 

		( isPedInVehicle ( source ) ) or ( getControlState ( source, "aim_weapon" ) ) then return end

		

    for k, v in pairs( banksInfo ) do

    	if marker == banksInfo[ k ].marker then

			local triggered = triggerEvent( "onPlayerEnterBank", source, banksInfo[ k ].marker, banksInfo[ k ].ATM )

			if triggered then

	    		setControlState( source, "forwards", false )

	    		setControlState( source, "backwards", false )

	    		setControlState( source, "left", false )

	    		setControlState( source, "right", false )

	    		--outputChatBox( tostring( playersAccount[ source ].balance ) );

	    		local try = triggerClientEvent( source, "bank_showBankAccountWnd", source, playersAccount[ source ]:accountname(), tostring( playersAccount[ source ].balance ), banksInfo[ k ].name, banksInfo[ k ].marker, banksInfo[ k ].depositAllowed )

	    		if not try then

	    			setTimer( triggerClientEvent, 100, 1, source, "bank_showBankAccountWnd", source, playersAccount[ source ]:accountname(), tostring( playersAccount[ source ].balance ), banksInfo[ k ].name, banksInfo[ k ].marker, banksInfo[ k ].depositAllowed )

	    		end

	    		playerInMarker[ source ] = marker

			end

			break

    	elseif banksInfo[ k ].entrance and marker == banksInfo[ k ].entrance.marker then

    		fadeCamera( source, false, 1 )

    		setTimer( setElementInterior, 1100, 1, source, 

                                                banksInfo[ k ].entrance.teleInterior,

                                                banksInfo[ k ].entrance.teleX,

                                                banksInfo[ k ].entrance.teleY,

                                                banksInfo[ k ].entrance.teleZ )

    		--setTimer( setPedRotation, 1100, 1, source, 90 )

    		setTimer( setPedRotation, 1100, 1, source, 90 )

    		setTimer( fadeCamera, 1100, 1, source, true, 1 )

    		setTimer( setCameraTarget, 1150, 1, source );

            break

    	elseif banksInfo[ k ]._exit and marker == banksInfo[ k ]._exit.marker then

    		fadeCamera( source, false, 1 )

    		setTimer( setElementInterior, 1100, 1, source, 

                                                banksInfo[ k ]._exit.teleInterior,

                                                banksInfo[ k ]._exit.teleX,

                                                banksInfo[ k ]._exit.teleY,

                                                banksInfo[ k ]._exit.teleZ )

    		--setTimer( setPedRotation, 1100, 1,

    		setTimer( setPedRotation, 1100, 1, source, banksInfo[ k ]._exit.teleRot )

    		setTimer( fadeCamera, 1100, 1, source, true, 1 )

    		setTimer( setCameraTarget, 1150, 1, source );

            break

    	end

    end

end

addEventHandler( "onPlayerMarkerHit", root, playerEnterMarker )



function playerLeaveBank( marker )

	if playerInMarker[ source ] then

	    for k, v in ipairs( banksInfo ) do

	        if marker == banksInfo[ k ].marker then

				triggerEvent( "onPlayerLeaveBank", source, marker, banksInfo[ k ].ATM )

	            triggerClientEvent( source, "bank_hideBankAccountWnd", source )

	            playerInMarker[ source ] = false

	            break

	        end

	    end

	end

end

addEventHandler( "onPlayerMarkerLeave", root, playerLeaveBank )





function withdrawMoney( player, money )

	local playerBankID = getBankID( getPlayerBank( player ) )

	if type( money ) == 'number' and playersAccount[ player ].balance < money then

	elseif type( money ) == 'string' and money == 'all' then

		money = playersAccount[ player ].balance

		if money > 0 then

			local atm = ( banksInfo[ playerBankID ].ATM and true or false )

			local triggered = triggerEvent( "onPlayerWithdrawMoney", player, getPlayerBank( player ), money, atm )

			if triggered then

				playersAccount[ player ]:withdraw( money, player )

			    bank_savePlayerMoney( player, getPlayerAccount( player ) )

				triggerClientEvent( player, "bank_updateMyBalance", player, playersAccount[ player ].balance )

			end

		end

    else

		if money > 0 then

			local atm = ( banksInfo[ playerBankID ].ATM and true or false )

			local triggered = triggerEvent( "onPlayerWithdrawMoney", player, getPlayerBank( player ), money, atm )

			if triggered then

				--outputChatBox( "You've withdrawn $"..tostring( money )..".", player, 255, 255, 0 )

				playersAccount[ player ]:withdraw( money, player )

		        bank_savePlayerMoney( player, getPlayerAccount( player ) )

				triggerClientEvent( player, "bank_updateMyBalance", player, playersAccount[ player ].balance )

			end

		end

	end

end

addEvent( "bank_withdrawMoney", true )

addEventHandler( "bank_withdrawMoney", root, withdrawMoney )


function depositMoney( player, money )

	local playerBankID = getBankID( getPlayerBank( player ) )

	if type( money ) == 'number' and getPlayerMoney( player ) >= money then

		local atm = ( banksInfo[ playerBankID ].ATM and true or false )

		local triggered = triggerEvent( "onPlayerDepositMoney", player, getPlayerBank( player ), money, atm )

		if triggered then

			playersAccount[ player ]:deposit( money )

			takePlayerMoney( player, money )

	        bank_savePlayerMoney( player, getPlayerAccount( player ) )

			triggerClientEvent( player, "bank_updateMyBalance", player, playersAccount[ player ].balance )

		end

    elseif type( money ) == 'string' and money == 'all' then

		money = getPlayerMoney( player )

		if money == 0 then

			return

		end

		local atm = ( banksInfo[ playerBankID ].ATM and true or false )

		local triggered = triggerEvent( "onPlayerDepositMoney", player, getPlayerBank( player ), money, atm )

		if triggered then

			playersAccount[ player ]:deposit( money )

	        takePlayerMoney( player, money )

	        bank_savePlayerMoney( player, getPlayerAccount( player ) )

			triggerClientEvent( player, "bank_updateMyBalance", player, playersAccount[ player ].balance )

		end

	end

end

addEvent( "bank_depositMoney", true )

addEventHandler( "bank_depositMoney", root, depositMoney )



function transferMoney(player, receiver, money, money2)

    local playerBankID = getBankID( getPlayerBank( player ) )

    if type( money ) == 'number' then

        if playersAccount[ player ].balance >= money then

            local atm = ( banksInfo[ playerBankID ].ATM and true or false )

            local triggered = triggerEvent( "onPlayerTransferMoney", player, getPlayerBank( player ), money, receiver, atm  )

            if triggered then

                local receiverName = getPlayerName(receiver)

                local senderName = getPlayerName(player)

                outputChatBox("Transfered $"..money2.." to "..receiverName.."", player, 0, 255, 0)

                outputChatBox(senderName.." Transfered $"..money2.." to you", receiver, 0, 255, 0)

                playersAccount[ player ]:withdraw( money, player, true )

                playersAccount[ receiver ]:deposit( money )

                triggerClientEvent( player, "bank_updateMyBalance", player, playersAccount[ player ].balance )

	        bank_savePlayerMoney( player, getPlayerAccount( player ) )

	        bank_savePlayerMoney( receiver, getPlayerAccount( receiver ) )

                if isPlayerInBank( receiver ) then

                    triggerClientEvent( receiver, "bank_updateMyBalance", receiver, playersAccount[ receiver ].balance )

                end

            end

        end

    else

        outputChatBox("Fill in an number!", player, 0, 255, 0)

        triggerClientEvent(player, "atm.setGUIback", player)

    end

end

addEvent( "bank_transferMoney", true )

addEventHandler( "bank_transferMoney", root, transferMoney )



function wit(player, amount)

    if playersAccount[ player ].balance >= amount then

        triggerClientEvent(player, "wit2", player)

    else

        outputChatBox("You don't have enough money", player, 255, 0, 0)

    end

end

addEvent("wit", true)

addEventHandler("wit", root, wit)



function depoo(player, amount)

    if getPlayerMoney(player) >= amount then

        triggerClientEvent(player, "depoo2", player)

    else

        outputChatBox("You don't have enough money", player, 255, 0, 0)

    end

end

addEvent("depo", true)

addEventHandler("depo", root, depoo)



function trans(player, amount, acc)

    if playersAccount[ player ].balance >= amount then

        local aa = getAccount(acc)

        if aa then

            local theAcc = getAccountPlayer(aa)

            if theAcc then

                triggerClientEvent(player, "transfer2", player, theAcc, amount)

            elseif not theAcc then

                outputChatBox("this player is not online!", player, 255, 0, 0)

            end

        elseif not aa then

            outputChatBox("there is not a player with this account name!", player, 255, 0, 0)

        end

    else

        outputChatBox("You don't have enough money in your bank!", player, 255, 0, 0)

    end

end

addEvent("exTrans", true)

addEventHandler("exTrans", root, trans)



_setPlayerMoney = setPlayerMoney;

function setPlayerMoney(player, money)

    takePlayerMoney(player, getPlayerMoney(player))

    givePlayerMoney(player, money)

end

