------------------------------------------------------------------------------------
--  RIGHTS:      All rights reserved by developers
--  FILE:        ATMsystem/SERVERevents.lua
--  PURPOSE:     ATM System v2.0
--  DEVELOPER:   A!ExXx AKA iAnnas
------------------------------------------------------------------------------------


addEvent( "onPlayerWithdrawMoney" );

addEvent( "onPlayerDepositMoney" );

addEvent( "onPlayerTransferMoney" );

addEvent( "onPlayerEnterBank" );

addEvent( "onPlayerEnterBankInterior" );

addEvent( "onPlayerLeaveBank" );

addEvent( "onPlayerLeaveBankInterior" );


