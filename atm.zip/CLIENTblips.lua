------------------------------------------------------------------------------------
--  RIGHTS:      All rights reserved by developers
--  FILE:        ATMsystem/CLIENTblips.lua
--  PURPOSE:     ATM System v2.0
--  DEVELOPER:   A!ExXx AKA iAnnas
------------------------------------------------------------------------------------


addEventHandler( "onClientColShapeHit", getResourceRootElement( getThisResource( ) ),

	function( element )

		if ( getElementType( element ) == "player" ) and element == getLocalPlayer( ) then

			local child = getElementChild( source, 0 )

			if getElementType( child ) == "marker" then

				local blip = createBlipAttachedTo( child, 52 )

				setElementParent( blip, child )

			end

		end

	end

)

addEventHandler( "onClientColShapeLeave", getResourceRootElement( getThisResource( ) ),

	function( element )

		if ( getElementType( element ) == "player" ) and element == getLocalPlayer( ) then

			local child = getElementChild( source, 0 )

			if getElementType( child ) == "marker" then

				for k, blip in pairs( getElementChildren( child ) ) do

					if getElementType( blip ) == "blip" then

						destroyElement( blip )

					end

				end

			end

		end

	end

)

addEventHandler("onClientResourceStart", getResourceRootElement(),

function()

	guiSetInputMode("no_binds_when_editing") 

end)





