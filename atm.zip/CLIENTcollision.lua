------------------------------------------------------------------------------------
--  RIGHTS:      All rights reserved by developers
--  FILE:        ATMsystem/CLIENTcollision.lua
--  PURPOSE:     ATM System v2.0
--  DEVELOPER:   A!ExXx AKA iAnnas
------------------------------------------------------------------------------------

addEventHandler( "onClientResourceStart", getResourceRootElement( getThisResource( ) ),

	function( )

		triggerServerEvent( "bank_giveMeATMs", root );

	end

)


addEvent( "bank_takeATMs", true );

addEventHandler( "bank_takeATMs", g_root, 

	function( ATMs )

		for k, atm in pairs( ATMs ) do

			setElementCollisionsEnabled( atm, false );

		end

	end

)