------------------------------------------------------------------------------------
--  RIGHTS:      All rights reserved by developers
--  FILE:        ATMsystem/CLIENTgui.lua
--  PURPOSE:     ATM System v2.0
--  DEVELOPER:   A!ExXx AKA iAnnas
------------------------------------------------------------------------------------

g_localPlayer = getLocalPlayer()

g_root = getRootElement()

local g_this_root = getResourceRootElement( getThisResource() )



local g_editHandlers = { }



function formatNumber(n)

    if (not n) then return "Error catching data" end

    local left,num,right = string.match(n,'^([^%d]*%d)(%d*)(.-)$')

    return left..(num:reverse():gsub('(%d%d%d)','%1,'):reverse())..right

end



function centerWindow(center_window)

    local screenW,screenH=guiGetScreenSize()

    local windowW,windowH=guiGetSize(center_window,false)

    local x,y = (screenW-windowW)/2,(screenH-windowH)/2

    guiSetPosition(center_window,x,y,false)

end



addEventHandler( "onClientResourceStart", g_this_root, 

	function( theResource )

	if theResource == getThisResource() then 

			local tempLbl



			bankWnd = guiCreateWindow(350, 120, 265, 495, "", false)

			guiWindowSetMovable(bankWnd, false)

			guiWindowSetSizable(bankWnd, false)

                        guiSetAlpha(bankWnd, 0.97)

                        centerWindow(bankWnd)



			tempLbl = guiCreateLabel(10, 25, 105, 15, "Account Balance:", false, bankWnd)

                        guiSetFont(tempLbl, "clear-normal")

			nothinglbl = guiCreateLabel(10, 70, 200, 15, "Withdrawals / Deposits", false, bankWnd)

                        guiSetFont(nothinglbl, "clear-normal")

			clientbalance_lbl = guiCreateLabel(119, 25, 105, 15, "", false, bankWnd)

                        guiSetFont(clientbalance_lbl, "clear-normal")

                        infoLbl1 = guiCreateLabel(11, 200, 250, 88, "To withdraw money from your account you\nmust enter your PIN code. NEVER TELL\nYOUR PIN CODE TO ANYONE. If you have\nentered the wrong PIN code 3 times in the\nlast 24 hours you'll have to wait a while, to\nchange PIN use /setpin NewPIN OldPIN", false, bankWnd)

                        pinLbl = guiCreateLabel(10, 310, 105, 15, "PIN:", false, bankWnd)

			Lable_Wait = guiCreateLabel(13, 43, 233, 23, " ", false, bankWnd)

                        pinEdit = guiCreateEdit(40, 300, 70, 40, "", false, bankWnd)

                        guiEditSetMasked(pinEdit, true)

                        guiEditSetMaxLength(pinEdit, 8)

                        infoLbl2 = guiCreateLabel(11, 350, 250, 60, "If you are transfering money to another\naccount enter their account name in the\nbox below:", false, bankWnd)



			withdrawTab = { }

			withdrawTab.amount = guiCreateEdit(10, 100, 250, 40, "", false, bankWnd)

			withdrawTab.button = guiCreateButton(98, 150, 70, 40, "Withdraw", false, bankWnd)

			addEventHandler( "onClientGUIClick", withdrawTab.button, with, false)

			

			depositTab = { }

			depositTab.button = guiCreateButton(10, 150, 70, 40, "Deposit", false, bankWnd)

			addEventHandler( "onClientGUIClick", depositTab.button, dep, false)

			

			transferTab = { }

			transferTab.to = guiCreateEdit(10, 403, 250, 32, "", false, bankWnd)

                        guiEditSetMaxLength( transferTab.to, 24 )

			transferTab.button = guiCreateButton(186, 150, 70, 40, "Transfer", false, bankWnd)

			addEventHandler("onClientGUIClick", transferTab.button, tr, false)

			

			quit_btn = guiCreateButton(170, 440, 88, 40, "Close", false, bankWnd)

			addEventHandler( "onClientGUIClick", quit_btn, 

				function()

                    if source == quit_btn then

                        guiSetVisible( bankWnd, false )

                        showCursor( false )

                        -- guiSetInputEnabled( false )

                    end

				end, false

			)

			

			guiSetVisible( bankWnd, false )

		end

	end

)



function wit2()

	local amount = nil

		amount = tonumber(guiGetText( withdrawTab.amount))

		if amount == nil then

                        -- outputChatBox("You must type the amount you want to withdraw!", 255, 0, 0)

        elseif amount < 0 then

            showWarningMessage("You can't enter negative values!")

		else

                        guiSetEnabled(bankWnd, false)

			triggerServerEvent("bank_withdrawMoney", g_localPlayer, g_localPlayer, amount)

		end

end

addEvent("wit2", true)

addEventHandler("wit2", root, wit2)



function dep()

    local amount = tonumber(guiGetText(withdrawTab.amount))

    if amount == nil then

       -- outputChatBox("You must type the amount you want to deposit!", 255, 0, 0)

    return end

    if amount >= 1 then

        triggerServerEvent("depo", g_localPlayer, g_localPlayer, amount)

    end

end



function depo()

    amount = tonumber(guiGetText(withdrawTab.amount))

    guiSetEnabled(bankWnd, false)

    triggerServerEvent("bank_depositMoney", g_localPlayer, g_localPlayer, amount)

end

addEvent("depoo2", true)

addEventHandler("depoo2", root, depo)



function with()

    local pin = guiGetText(pinEdit)

    local data = getElementData(localPlayer, "ATMPW")

    if (pin == "") and (data) then outputChatBox("You didn't enter PIN code", 255, 0, 0) return end

    if (pin ~= data) and (data) then

    outputChatBox("You have entered invalid PIN code!", 255, 0, 0) return end

    amount = tonumber(guiGetText(withdrawTab.amount))

    if amount and amount >= 1 then

        triggerServerEvent("wit", g_localPlayer, g_localPlayer, amount)

    end

end



function checkPIN()

local checker = getElementData(getLocalPlayer(), "ATMPW")

if (checker) then

guiSetEnabled(pinEdit, true)

else

guiSetEnabled(pinEdit, false)

   end

end

setTimer(checkPIN, 100, 0)



function tr()

    local pin = guiGetText(pinEdit)

    local data = getElementData(localPlayer, "ATMPW")

    if (pin == "") and (data) then outputChatBox("You didn't enter PIN code", 255, 0, 0) return end

    if (pin ~= data) and (data) then

    outputChatBox("You have entered invalid PIN code!", 255, 0, 0) return end

    local amount = tonumber(guiGetText(withdrawTab.amount))

    if amount and amount >= 1 then

        local acc = guiGetText(transferTab.to)

        if acc == "" then return end

        triggerServerEvent("exTrans", g_localPlayer, g_localPlayer, amount, acc)

    end

end



function transferMoney(theAcc)

    local to_who = guiGetText(transferTab.to)

    amount = tonumber(guiGetText(withdrawTab.amount))

    if to_who == nil or to_who == false or to_who == "" then return end

    local money_receiver = theAcc

    if money_receiver == g_localPlayer then

        outputChatBox("You can not transfer money to yourself!", 255, 0, 0)

    elseif money_receiver ~= g_localPlayer then

        guiSetEnabled(bankWnd, false)

        local money2 = formatNumber(amount)

        triggerServerEvent("bank_transferMoney", g_localPlayer, g_localPlayer, money_receiver, amount, money2)

    end

end

addEvent("transfer2", true)

addEventHandler("transfer2", root, transferMoney)



function show_MyBankAccountWnd(name, money, bankname, bank, atm)

	showCursor(true)

        guiSetText(bankWnd, bankname)

        local theMoney = tostring(money)

        local theMoney2 = formatNumber(theMoney)

	guiSetText(clientbalance_lbl, "$"..theMoney2)

	guiSetVisible( bankWnd, true )

	guiBringToFront( bankWnd )

        guiSetInputMode("no_binds_when_editing")

	local r,g,b = getPlayerNametagColor( g_localPlayer )

	if r < 80 and g < 80 and b < 80 then -- if color is too dark, set it to white

		r, g, b = 250, 250, 250

	end

end

addEvent( "bank_showBankAccountWnd", true )

addEventHandler( "bank_showBankAccountWnd", g_localPlayer, show_MyBankAccountWnd )



function hide_MyBankAccountWnd( )

	guiSetVisible( bankWnd, false )

	showCursor( false )

end

addEvent( "bank_hideBankAccountWnd", true )

addEventHandler( "bank_hideBankAccountWnd", g_localPlayer, hide_MyBankAccountWnd )



function updateMyBalance(currBalance)

    local balance = tostring(currBalance)

    local balance2 = formatNumber(balance)

    guiSetText(clientbalance_lbl, "$"..balance2)

    setTimer(function()

        guiSetEnabled(bankWnd, true)

        showCursor(true)

    end, 1000, 1)

end

addEvent("bank_updateMyBalance", true)

addEventHandler("bank_updateMyBalance", g_localPlayer, updateMyBalance)



function setGUIback(currBalance)

    setTimer(function()

        guiSetEnabled(bankWnd, true)

    end, 100, 1)

end

addEvent("atm.setGUIback", true)

addEventHandler("atm.setGUIback", root, setGUIback)