carShopMarker = createMarker (2133.59,-1149.29, 23.3, "cylinder", 3, 255, 0, 0, 127)
carShopMarker2 = createMarker (562, -1270, 16, "cylinder", 2, 255, 0, 0, 127)
carShopMarker3 = createMarker (-1954,299,34,"cylinder",2,255,0,0,127)
carShopMarker4 = createMarker (-1663,1208,6,"cylinder",2,255,0,0,127)
carShopMarker5 = createMarker (1946,2068,10,"cylinder",2,255,0,0,127)
createBlipAttachedTo(carShopMarker,55,2,0,255,0,0,0,200)
createBlipAttachedTo(carShopMarker2,55,2,0,255,0,0,0,200)
createBlipAttachedTo(carShopMarker3,55,2,0,255,0,0,0,200)
createBlipAttachedTo(carShopMarker4,55,2,0,255,0,0,0,200)
createBlipAttachedTo(carShopMarker5,55,2,0,255,0,0,0,200)

addEvent ("viewGUI", true)
function markerHit (hitPlayer, matchingDimension)
  if (source == carShopMarker) or (source == carShopMarker2) or (source == carShopMarker3) or (source == carShopMarker4) or (source == carShopMarker5) then
    triggerClientEvent ("viewGUI", hitPlayer)
  end
end
addEventHandler ("onMarkerHit", getRootElement(), markerHit)

addEvent ("carShopCarBuy", true)
addEventHandler ("carShopCarBuy", getRootElement(), 
function(id, cost, name)
  if (getPlayerMoney (source) >= tonumber(cost)) then
    outputChatBox ("Bought a " .. name, source, 255, 0, 0, false)
    outputChatBox ("ID: " .. id, source, 255, 0, 0, false)
    outputChatBox ("Cost: " .. cost, source, 255, 0, 0, false)
    takePlayerMoney (source, tonumber (cost))
    setAccountData (getPlayerAccount (source), "funmodev2-car", tonumber(id))
    setAccountData (getPlayerAccount (source), "funmodev2-paintjob", 3)
    setAccountData (getPlayerAccount (source), "funmodev2-carupg", 0)
  else
    outputChatBox ("You are too poor!", source, 255, 0, 0, false)
  end
end)


addEvent ("carSpawn", true)
addEvent ("carDestroy", true)


function carSpawn ()
  if not (isGuestAccount (getPlayerAccount (source))) and not (isPedInVehicle(source)) then
    if (getElementData (source, "hisCar")) and (getElementData (source, "hisCar") ~= nil) and (getElementType(getElementData (source, "hisCar")) == "vehicle") then
      setElementVelocity (getElementData (source, "hisCar"), 0,0,0)
      local x,y,z = getElementPosition (source)
      setVehicleRotation (getElementData (source, "hisCar"), 0, 0, 0)
      setElementPosition (getElementData (source, "hisCar"), x+2,y,z +1)
      outputChatBox ("Car spawned.", source, 255, 0, 0)
    elseif not (getElementData (source, "hisCar")) then
      local accountData = getAccountData (getPlayerAccount (source), "funmodev2-car")
      if (accountData) then
        carID = getAccountData (getPlayerAccount (source), "funmodev2-car")
        x,y,z = getElementPosition (source)
        vehicle = createVehicle (carID, x +2, y, z +1)
        setElementID (vehicle, getAccountName (getPlayerAccount(source)))
        setElementData (source, "hisCar", vehicle)
        outputChatBox ("Car spawned.", source, 255, 0, 0)
        if (getAccountData (getPlayerAccount(source), "funmodev2-carupg")) then
          local upgrades = nil
          local upgrades = {}
          local upgrades = getAccountData (getPlayerAccount(source), "funmodev2-carupg")
          for i,v in ipairs (upgrades) do
            addVehicleUpgrade (vehicle, v)
          end
        end
        if (getAccountData (getPlayerAccount(source), "funmodev2-paintjob")) then
          local paintjob = getAccountData (getPlayerAccount(source), "funmodev2-paintjob")
          setVehiclePaintjob (vehicle, paintjob)
        end
        if (getAccountData (getPlayerAccount(source), "funmodev2-carcolor1")) and (getAccountData (getPlayerAccount(source), "funmodev2-carcolor2")) then
          local c1 = getAccountData (getPlayerAccount(source), "funmodev2-carcolor1")
          local c2 = getAccountData (getPlayerAccount(source), "funmodev2-carcolor2")
          setVehicleColor (vehicle, c1,c2,0,0)
        end
      else
        outputChatBox ("You haven't got a car.", source, 255, 0, 0)
      end
    else
      outputChatBox ("You're already in a car!", source, 255, 0, 0)
    end
  end
end
addEventHandler ("carSpawn", getRootElement(), carSpawn)

function carDestroy () 
  if  not (isGuestAccount (getPlayerAccount (source))) then
    if (isPedInVehicle (source)) then
      if (getElementID(getPedOccupiedVehicle(source)) == getAccountName (getPlayerAccount(source))) then
        setElementHealth (getElementData (source, "hisCar"), 0)
        destroyElement (getPedOccupiedVehicle (source))
        removeElementData (source, "hisCar")
        outputChatBox ("Car Destroyed.", source, 255, 0, 0)
      else
        outputChatBox ("This not your car!", source, 255, 0, 0)
      end
    elseif (not (isPedInVehicle (source))) and (getElementData (source, "hisCar")) and (getElementData (source, "hisCar") ~= nil) then
	  car=getElementData(source, "hisCar")
	  destroyElement(car)
      outputChatBox ("Car Destroyed.", source, 255, 0, 0)
      removeElementData (source, "hisCar")
    end
  end
end
addEventHandler ("carDestroy", getRootElement(), carDestroy)

function engineSwitch ()
  if (isPedInVehicle (source)) then
    local veh = getPedOccupiedVehicle (source)
    if (getVehicleEngineState (veh) == true) then
      setVehicleEngineState (veh, false)
      outputChatBox ("Vehicle shutted down.", source, 255, 0, 0)
    elseif (getVehicleEngineState (veh) == false) then
      setVehicleEngineState (veh, true)
      outputChatBox ("Vehicle started.", source, 255, 0, 0)
    end
  else
    outputChatBox ("You aren't in a vehicle!", source, 255, 0, 0)
  end
end
addEvent("engenieSwitch",true)
addEventHandler("engenieSwitch",getRootElement(),engineSwitch)

function lightsSwitch ()
  if (isPedInVehicle (source)) then
    local veh = getPedOccupiedVehicle (source)
    if (getVehicleOverrideLights(veh) ~= 2) then
	  setVehicleOverrideLights(veh, 2)
      outputChatBox ("Vehicle lights turned on.", source, 255, 0, 0)
    elseif (getVehicleOverrideLights(veh) ~= 1) then
      setVehicleOverrideLights(veh, 1)
      outputChatBox ("Vehicle lights turned off.", source, 255, 0, 0)
    end
  else
    outputChatBox ("You aren't in a vehicle!", source, 255, 0, 0)
  end
end
addEvent("lightsSwitch",true)
addEventHandler("lightsSwitch",getRootElement(),lightsSwitch)

function lockSwitch ()
  if (isPedInVehicle (source)) then
	local veh = getPedOccupiedVehicle (source)
    if not (isVehicleLocked (veh)) then
      setVehicleLocked (veh, true)
      setVehicleDoorsUndamageable (veh, true)
      setVehicleDoorState (veh, 0, 0)
      setVehicleDoorState (veh, 1, 0)
      setVehicleDoorState (veh, 2, 0)
      setVehicleDoorState (veh, 3, 0) 
      outputChatBox ("Vehicle locked.", source, 255, 0, 0)
    elseif (isVehicleLocked (veh)) then
      setVehicleLocked (veh, false)
      setVehicleDoorsUndamageable (veh, false)
      outputChatBox ("Vehicle unlocked.", source, 255, 0, 0)
    end
  else
    outputChatBox ("You aren't in a vehicle!", source, 255, 0, 0)
  end
end
addEvent("lockSwitch",true)
addEventHandler("lockSwitch",getRootElement(),lockSwitch )

addEventHandler ("onVehicleStartEnter", getRootElement(), 
function(player, seat, jacked, door)
  if (isVehicleLocked (source) == true) then
    local mannetjeNaam = getAccountName (getPlayerAccount (player))
    local autoNaam = getElementID (source)
    if (mannetjeNaam == autoNaam) then
      setVehicleLocked (source, false)
      outputChatBox ("Vehicle unlocked!", player, 255, 0, 0, false)
    end
  end
end)


addEventHandler ("onVehicleExplode", getRootElement(), 
function()
  local theOwner = getAccountName (getPlayerAccount(getPlayerFromName (getElementID (source))))
  if (theOwner) then
    removeElementData (theOwner, "hisCar")
  end
end)

addEventHandler ("onPlayerQuit", getRootElement(), 
function(quitType, reason, responsibleElement)
  if (getElementData (source, "hisCar")) then
    blowVehicle (getElementData (source, "hisCar"))
    removeElementData (source, "hisCar")
  end
end)

addEventHandler( "onResourceStop", getResourceRootElement( getThisResource() ),
	function ()
		for i,v in ipairs (getElementsByType ("player")) do
			if (getElementData (v, "hisCar")) then
				setElementHealth (getElementData (v, "hisCar"), 0)
				removeElementData (v, "hisCar")
			end
		end
	end
)

function destroyOnExplode ()
	setTimer (destroyElement, 2500, 1, source)
end
addEventHandler ("onVehicleExplode", getRootElement(), destroyOnExplode)

