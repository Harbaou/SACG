-----------------------------------------------------
-- @script  Custom Event System
-- @author XeoN
-- @version 1.0
-----------------------------------------------------




local acls = {"Console", "Admin", "SuperModerator", "Moderator"}
local on = "nao"
local coisa = nil
local eventVehicles = {}
local eventPlayers = {}




local vehicleIDS = { 602, 545, 496, 517, 401, 410, 518, 600, 527, 436, 589, 580, 419, 439, 533, 549, 526, 491, 474, 445, 467, 604, 426, 507, 547, 585,
405, 587, 409, 466, 550, 492, 566, 546, 540, 551, 421, 516, 529, 592, 553, 577, 488, 511, 497, 548, 563, 512, 476, 593, 447, 425, 519, 520, 460,
417, 469, 487, 513, 581, 510, 509, 522, 481, 461, 462, 448, 521, 468, 463, 586, 472, 473, 493, 595, 484, 430, 453, 452, 446, 454, 485, 552, 431, 
438, 437, 574, 420, 525, 408, 416, 596, 433, 597, 427, 599, 490, 432, 528, 601, 407, 428, 544, 523, 470, 598, 499, 588, 609, 403, 498, 514, 524, 
423, 532, 414, 578, 443, 486, 515, 406, 531, 573, 456, 455, 459, 543, 422, 583, 482, 478, 605, 554, 530, 418, 572, 582, 413, 440, 536, 575, 534, 
567, 535, 576, 412, 402, 542, 603, 475, 449, 537, 538, 441, 464, 501, 465, 564, 568, 557, 424, 471, 504, 495, 457, 539, 483, 508, 571, 500, 
444, 556, 429, 411, 541, 559, 415, 561, 480, 560, 562, 506, 565, 451, 434, 558, 494, 555, 502, 477, 503, 579, 400, 404, 489, 505, 479, 442, 458, 
606, 607, 610, 590, 569, 611, 584, 608, 435, 450, 591, 594 }

-- Removing all players from the event when the resource stops.
addEventHandler("onResourceStop", resourceRoot,
function ()
        for _, p in ipairs(getElementsByType("player")) do
             if (eventPlayers[p]) then
			eventPlayers[p] = nil 
         end
	 end
end)

-- Removing the wasted player from event.
addEventHandler("onPlayerWasted", root,
function ()
    if eventPlayers[source] then 
	   eventPlayers[source] = nil 
    end
end)

-- Event when player quit , removing from eventplayers table

addEventHandler("onPlayerQuit", root,
function ()
    if eventPlayers[source] then 
	   eventPlayers[source] = nil 
	end
end)


-- event functions
function event (thePlayer)
    if not (isAllownedPlayer(thePlayer)) then
        return
    end
    if(on == "sim")then
        thePlayer:outputChatBox("#FFF000[SERVER]#FFFFFF Event is already created, use #FF0000/devent#FFFFFF to close the Event!",255,255,255,true)
    else
        local x,y,z = getElementPosition(thePlayer)
        on = "sim"
        coisa = createMarker(x,y,z-1,"cylinder",1,255,0,0)
        dimen = thePlayer:getDimension()
        inte = thePlayer:getInterior()
        outputChatBox("#FFF000[SERVER]#FFFFFF Administator #FF0000"..getPlayerName(thePlayer).."#FFFFFF created a event, write #FF0000/irevento#FFFFFF to participate!",root,255,255,255,true)

        if(inte)then
            coisa:setInterior(inte)
        end

        if(dimen)then
            coisa:setDimension(dimen)
        end
    end
end
addCommandHandler("makeevent", event)

function destroy (thePlayer)
    -- check player
    if not (isAllownedPlayer(thePlayer)) then
        return
    end

    if(on == "nao")then
        thePlayer:outputChat("#FFF000[SERVER]#FFFFFF There isn't a event, use #FF0000/cevent #FFFFFF to create a event!",255,255,255,true)
    else 
        if (isElement(coisa)) then
           outputChatBox("#FFF000[SERVER]#FFFFFF Administator #FF0000"..getPlayerName(thePlayer).." #FFFFFF Closed the event!", root, 255,255,255, true)
            on = "nao"
            coisa:destroy()
        end
     end 
end   
addCommandHandler("devent", destroy)

function irevento(thePlayer,cmd)
    if(on == "sim")then 
	    local x,y,z = getElementPosition(coisa)
        if thePlayer:getOccupiedVehicle() then
           thePlayer:outputChat("#FFF000[SERVER]#FFFFFF Leave your vehicle to enter the event",255,255,255,true)
        else
            if eventPlayers[thePlayer]  then -- if the var "Evento" is true then say to player:
                thePlayer:outputChat("#FFF000[SERVER]#FFFFFF You're already at the event.",255,255,255,true)
            else
                -- only take weapons and give armor and helth if the player joined in event.
                takeAllWeapons ( thePlayer )            
                thePlayer:setHealth(100)
                thePlayer:setArmor(100)
                eventPlayers[thePlayer] = true  -- Add the player to eventPlayer table
                thePlayer:setPosition(x,y,z+1) -- set player position
				thePlayer:setDimension(coisa:getDimension())
                thePlayer:setInterior(inte)
                thePlayer:outputChat("#FFF000[SERVER]#FFFFFF Welcome in the Event!",255,255,255,true)
            end
        end
    else
        thePlayer:outputChat("#FFF000[SERVER]#FFFFFF There isn't a event created!",255,255,255,true)
    end
end
addCommandHandler("irevento",irevento)


function getWeapons ( thePlayer )
     if(on == "sim") then
    -- check player
    if not (isAllownedPlayer(thePlayer)) then
        return
    end
local list1 = 0
    for _, player in ipairs(getElementsByType("player")) do
        if eventPlayers[player] then 
            takeAllWeapons (player)
            player:outputChat("#FFF000[EVENTO]#FFFFFF "..getPlayerName(thePlayer).." removed your weapons", 255, 255, 255, true)
            list1 = list1 + 1
        end
    end
 thePlayer:outputChat("#FFF000[EVENTO]#FFFFFF You removed weapons of "..list1.."  players ", 255, 255, 255, true)
  end
end
addCommandHandler ("tweapons",getWeapons)

function GiveHealthAndArmour ( thePlayer )
   --  if(on == "sim") then
    -- check player
    if not (isAllownedPlayer(thePlayer)) then
        return
    end
    local listt = 0
    for _, player in ipairs(getElementsByType("player")) do
        if eventPlayers[player] then 
            player:setHealth(100)
            player:setArmor(100)
            player:outputChat("#FFF000[EVENTO]#FFFFFF "..getPlayerName(thePlayer).." Given you  health & armour", 255, 255, 255, true)
             listt = listt + 1
        end
    end
   thePlayer:outputChat("#FFF000[EVENTO]#FFFFFF You given health and armour  to "..listt.." players,", 255, 255, 255, true)
  end
--end

addCommandHandler ("givehp",GiveHealthAndArmour)

function Frooze ( thePlayer )
  --   if(on == "sim") then
    -- check player
    if not (isAllownedPlayer(thePlayer)) then
        return
    end
local list3 = 0
    for _, player in ipairs(getElementsByType("player")) do
            if eventPlayers[player] then 
			player:toggleControl("fire",false)
			player:toggleControl("next_weapon",false)
			player:toggleControl("left",false)
			player:toggleControl("right",false)
			player:toggleControl("jump",false)
			player:toggleControl("sprint",false)
			player:toggleControl("forwards",false)
			player:toggleControl("backwards",false)
			player:toggleControl("walk",false)
			player:toggleControl("previous_weapon",false)
			player:toggleControl("aim_weapon",false)
			player:toggleControl("crouch",false)
			player:toggleControl("enter_exit",false)
			player:toggleControl("vehicle_fire",false)
			player:toggleControl("vehicle_secondary_fire",false)
			player:toggleControl("vehicle_left",false)
			player:toggleControl("vehicle_right",false)
			player:toggleControl("vehicle_forward",false)
			player:toggleControl("streer_back",false)
			player:toggleControl("accelerate",false)
			player:toggleControl("brake_reverse",false)
			player:toggleControl("handbrake",false)
            player:outputChat("#FFF000[EVENTO]#FFFFFF "..getPlayerName(thePlayer).." Froozen you", 255, 255, 255, true)
            list3 = list3 + 1
        end
    end
thePlayer:outputChat("#FFF000[EVENTO]#FFFFFF You froozen "..list3.." players ",  255, 255, 255, true)
 -- end
end
addCommandHandler ("frooze",Frooze)

function UnFrooze ( thePlayer )
  --   if(on == "sim") then
    -- check player
    if not (isAllownedPlayer(thePlayer)) then
        return
    end
local list4 = 0
    for _, player in ipairs(getElementsByType("player")) do
            if eventPlayers[player] then 
			player:toggleControl("fire",true)
			player:toggleControl("next_weapon",true)
			player:toggleControl("left",true)
			player:toggleControl("right",true)
			player:toggleControl("jump",true)
			player:toggleControl("sprint",true)
			player:toggleControl("forwards",true)
			player:toggleControl("backwards",true)
			player:toggleControl("walk",true)
			player:toggleControl("previous_weapon",true)
			player:toggleControl("aim_weapon",true)
			player:toggleControl("crouch",true)
			player:toggleControl("enter_exit",true)
			player:toggleControl("vehicle_fire",true)
			player:toggleControl("vehicle_secondary_fire",true)
			player:toggleControl("vehicle_left",true)
			player:toggleControl("vehicle_right",true)
			player:toggleControl("vehicle_forward",true)
			player:toggleControl("streer_back",true)
			player:toggleControl("accelerate",true)
			player:toggleControl("brake_reverse",true)
			player:toggleControl("handbrake",true)
            player:outputChat("#FFF000[EVENTO]#FFFFFF "..getPlayerName(thePlayer).." UnFroozen you", 255, 255, 255, true)
            list4 = list4 + 1
        end
    end
   thePlayer:outputChat("#FFF000[EVENTO]#FFFFFF You unfroozen "..list4.." players ", 255, 255, 255, true)
 -- end
end
addCommandHandler ("unfrooze", UnFrooze)

function giveWeaponCommand ( thePlayer, cmd, weaponID )
  --   if(on == "sim") then
    if not (isAllownedPlayer(thePlayer)) then return end
 
    weaponID = tonumber(weaponID)
    if not (weaponID) or (weaponID > 46) then thePlayer:outputChat("#FFF000[EVENTO]#FFFFFF Invalid weapon ID.", 255,255,255, true) return end
    local list = 0
    for _, player in ipairs(getElementsByType("player")) do
            if eventPlayers[player] then 
            player:giveWeapon ( weaponID, 9999,true )
            player:outputChat("#FFF000[EVENTO]#FFFFFF "..getPlayerName(thePlayer).." Given you a " .. getWeaponNameFromID(weaponID) .. "!", 255, 255, 255, true)
            list = list + 1
        end
    end
    thePlayer:outputChat("#FFF000[EVENTO]#FFFFFF You given " .. getWeaponNameFromID(weaponID) .. "! to "..list.." players", 255, 255, 255, true)
 -- end
end
addCommandHandler("gweapon", giveWeaponCommand)


function giveVehicleCommand ( thePlayer, cmd, vehicleID )
  --   if(on == "sim") then
    -- check player
    if not (isAllownedPlayer(thePlayer)) then
        return
    end
local list5 = 0
    vehicleID = tonumber(vehicleID)
    if not (vehicleID) or not (isValidVehicleID(vehicleID)) then
        thePlayer:outputChat("#FFF000[EVENTO]#FFFFFF Invalid vehicle ID.", 255,255,255, true)
        return
    end

    for _, p in ipairs(getElementsByType("player")) do
            if eventPlayers[p] then 
            -- check if not exists another vehicle
            if (eventVehicles[p]) and (isElement(eventVehicles[p])) then
                destroyElement(eventVehicles[p])
            end

            local x,y,z = getElementPosition(p)
            dimen = p:getDimension()
            local RaceVehicle = Vehicle.create ( vehicleID, x, y, z )
            eventVehicles[p] = RaceVehicle -- storage the vehicle in a table where player is a key of this table.
			RaceVehicle:setDimension(dimen)
            p:warpIntoVehicle(RaceVehicle)
            p:outputChat("#FFF000[EVENTO]#FFFFFF "..getPlayerName(thePlayer).." #ffffffGiven you a ".. getVehicleNameFromModel(vehicleID) .."!", 255, 255, 255, true)
            list5 = list5 + 1
        end
    end
     thePlayer:outputChat("#FFF000[EVENTO]#FFFFFF You given ".. getVehicleNameFromModel(vehicleID) .."! to "..list5.." players ", 255, 255, 255, true)
 -- end
end
addCommandHandler ("gcar", giveVehicleCommand)
 
function destroyVehicleCommand ( thePlayer )
 --    if(on == "sim") then
    -- check player
    if not (isAllownedPlayer(thePlayer)) then
        return
    end
local list6 = 0
    for _, p in ipairs(getElementsByType("player")) do
            if eventPlayers[p] then 
            local veh = eventVehicles[p]
            if (veh) and (isElement(veh)) then
                destroyElement(veh)
                p:outputChat("#FFF000[EVENTO]#FFFFFF "..getPlayerName(thePlayer).." #ffffffRemoved your vehicle!", 255, 255, 255, true)
                list6 = list6 + 1
            end
        end
        end
thePlayer:outputChat("#FFF000[EVENTO]#FFFFFF  You removed vehicles of "..list6.." players ", 255, 255, 255, true )
   --   end
end
addCommandHandler ("dcar", destroyVehicleCommand)


function KillAll ( thePlayer )
   --  if(on == "sim") then
    -- check player
    if not (isAllownedPlayer(thePlayer)) then
        return
    end
    local list8 = 0
    for _, player in ipairs(getElementsByType("player")) do
        if eventPlayers[player] then 
         player:kill()
            player:outputChat("#FFF000[EVENTO]#FFFFFF "..getPlayerName(thePlayer).." Killed you", 255, 255, 255, true)
             list8 = list8 + 1
        end
    end
       thePlayer:outputChat("#FFF000[EVENTO]#FFFFFF You Killed "..list8.." players", 255, 255, 255, true)
 end
--end
addCommandHandler ("killall",KillAll)


-- Utils functions
function isAllownedPlayer(player)
    local account = getPlayerAccount(player)
    if (not account or isGuestAccount(account)) then return false end
    local accountName = getAccountName(account)
    for i, v in pairs ( acls ) do
        if ( isObjectInACLGroup ( "user.".. accountName, aclGetGroup ( v ) ) ) then
            return true
        end
    end
    outputChatBox("#FFF000[SERVER]#FFFFFF You aren't an admin.", player, 255,255,255, true)
    return false
end

function isValidVehicleID(vehicleID)
    for i, vehID in ipairs (vehicleIDS) do
        if (vehID == vehicleID) then
            return true
        end
    end

    return false
end
