function onLogin(username,password,checkboxState)
	if not (username == "") then
		if not (password == "") then
			local account = getAccount ( username, password )
			if ( account ~= false ) then
				logIn(source, account, password)
				triggerClientEvent (source,"hideLoginPanel",getRootElement())
				triggerClientEvent (source,"saveXML",getRootElement(),username,password,tostring(checkboxState))
			else
				triggerClientEvent(source,"changeMessage",getRootElement(),"1","Welcome, please log in.", "red")
			end
		else
			triggerClientEvent(source,"changeMessage",getRootElement(),"1","Please enter your password.", "red")
		end
	else
		triggerClientEvent(source,"changeMessage",getRootElement(),"1","Please enter your username.", "red")
	end
end
addEvent("onLogin",true)
addEventHandler("onLogin",getRootElement(),onLogin)

function onRegister(username,password)
	if not (username == "") then
		if not (password == "") then
					local account = getAccount (username)
					if (account == false) then
						addAccount(tostring(username),tostring(password))
						triggerClientEvent(source,"changeMessage",getRootElement(),"2","Successfully registered.", "green")
						triggerClientEvent(source,"changeMessage",getRootElement(),"1","Successfully registered, log in.", "green")
						triggerClientEvent(source,"pressBack", getRootElement())
					else
						triggerClientEvent(source,"changeMessage",getRootElement(),"2","This username already taken.", "red")
					end
		else
			triggerClientEvent(source,"changeMessage",getRootElement(),"2","Please enter your password.", "red")
		end
	else
		triggerClientEvent(source,"changeMessage",getRootElement(),"2","Please enter your username.", "red")
	end
end
addEvent("onRegister",true)
addEventHandler("onRegister",getRootElement(),onRegister) 


