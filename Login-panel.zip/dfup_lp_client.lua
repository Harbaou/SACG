sW,sH = guiGetScreenSize()
mX, mY = 0, 0
myFont = dxCreateFont( "opensans-light.ttf", 15 )
logoW, logoH = sW/8.4, sW/8.4
bgY = 0

local screenWidth,screenHeight = guiGetScreenSize()

function createLoginPanel()
    addEventHandler("onClientRender",getRootElement(),renderLoginPanel)
    addEventHandler("onClientRender",getRootElement(),renderButtons)
    showCursor(true,true)
    toggleAllControls(false)
    showChat(false)
    xml = xmlLoadFile("userdata.xml")
    loadXML()
end
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), createLoginPanel)

function loadXML()
  if not xml then
    xml = xmlCreateFile("userdata.xml","userdata")
    usernameChild = xmlCreateChild(xml,"username")
    passwordChild = xmlCreateChild(xml,"password")
    checkboxChild = xmlCreateChild(xml,"state")
    xmlSaveFile(xml)
  else
    usernameChild = xmlFindChild(xml,"username",0)
    passwordChild = xmlFindChild(xml,"password",0)
    checkboxChild = xmlFindChild(xml,"state",0)
  end
  if xmlNodeGetValue(checkboxChild) == "true" then
    checkboxs[1].state = true
  end
    usernameLoad = xmlNodeGetValue(usernameChild)
    passwordLoad = xmlNodeGetValue(passwordChild)
    for w in string.gmatch(usernameLoad, ".") do
      for i,ebox in ipairs(editbox) do
        if ebox.name == "username" then
          table.insert(text[i], w)
        end
      end
    end
    for w in string.gmatch(passwordLoad, ".") do
      for i,ebox in ipairs(editbox) do
        if ebox.name == "password" then
          table.insert(text[i], w)
        end
      end
    end
end
function saveXML(username,password,checkboxState)
  if checkboxs[1].state == true then
    xmlNodeSetValue(usernameChild,username)
    xmlNodeSetValue(passwordChild,password)
    xmlNodeSetValue(checkboxChild,tostring(checkboxState))
    xmlSaveFile(xml)
  else
    xmlNodeSetValue(usernameChild,"")
    xmlNodeSetValue(passwordChild,"")
    xmlNodeSetValue(checkboxChild,"")
    xmlSaveFile(xml)
  end
end
addEvent("saveXML",true)
addEventHandler("saveXML",getRootElement(),saveXML)
boxes = {
  {x = sW/2-sW/10, y = sH/2-sH/7, w = sW/5, h = sH/20, borderColor = tocolor(13, 151, 82), boxD = "green", text = "Welcome, please log in.", messageBox = "1"},
	{x = sW/2-sW/10, y = sH/2-sH/7.4+sH/18, w = sW/5, h = sW/5, borderColor = tocolor(13, 151, 82)},
  {x = sW/2-sW/10, y = sH/2-sH/7 + sH, w = sW/5, h = sH/20, borderColor = tocolor(13, 151, 82), boxD = "green", text = "Write username and password.", messageBox = "2"},
  {x = sW/2-sW/10, y = sH/2-sH/7.4+sH/18 + sH, w = sW/5, h = sW/5, borderColor = tocolor(13, 151, 82)},
}
buttons = {
  {x = boxes[2].x + sW/47, y = boxes[2].y + boxes[2].h - sH/14, w = sW/13, h = boxes[2].w/6.5, color = tocolor(255,255,255), borderColor = tocolor(13, 151, 82), text = "Register", func = "pressRegisterBut"},
  {x = boxes[2].x + boxes[2].w - sW/47 - sW/13, y = boxes[2].y + boxes[2].h - sH/14, w = sW/13, h = boxes[2].w/6.5, color = tocolor(255,255,255), borderColor = tocolor(13, 151, 82), text = "Log In", func = "pressLogin"},
  {x = boxes[2].x + boxes[2].w - sW/47 - sW/13, y = boxes[2].y + boxes[2].h - sH/14 + sH, w = sW/13, h = boxes[2].w/6.5, color = tocolor(255,255,255), borderColor = tocolor(13, 151, 82), text = "Back", func = "pressBack"},
  {x = boxes[2].x + sW/47, y = boxes[2].y + boxes[2].h - sH/14 + sH, w = sW/13, h = boxes[2].w/6.5, color = tocolor(255,255,255), borderColor = tocolor(13, 151, 82), text = "Register", func = "pressRegister"}
}
editbox = {
  {x = boxes[2].x + sW/47, y = boxes[2].y + boxes[2].w/6.5, w = sW/13 + sW/13 + (boxes[2].w - sW/47 - sW/13 - sW/47 - sW/13), h = boxes[2].w/6.5, borderColor = tocolor(13, 151, 82), textUp = "Username.", text = "", name = "username"},
  {x = boxes[2].x + sW/47, y = boxes[2].y + boxes[2].w/6.5 + boxes[2].w/6.5 + boxes[2].w/6.5, w = sW/13 + sW/13 + (boxes[2].w - sW/47 - sW/13 - sW/47 - sW/13), h = boxes[2].w/6.5, borderColor = tocolor(13, 151, 82), textUp = "Password.", text = "", hide = true, name = "password"},
  {x = boxes[2].x + sW/47, y = boxes[2].y + boxes[2].w/6.5 + sH, w = sW/13 + sW/13 + (boxes[2].w - sW/47 - sW/13 - sW/47 - sW/13), h = boxes[2].w/6.5, borderColor = tocolor(13, 151, 82), textUp = "Username.", text = "", name = "usernameReg"},
  {x = boxes[2].x + sW/47, y = boxes[2].y + boxes[2].w/6.5 + boxes[2].w/6.5 + boxes[2].w/6.5 + sH, w = sW/13 + sW/13 + (boxes[2].w - sW/47 - sW/13 - sW/47 - sW/13), h = boxes[2].w/6.5, borderColor = tocolor(13, 151, 82), textUp = "Password.", text = "", hide = true, name = "passwordReg"},
}
checkboxs = {
  {x = boxes[2].x + sW/47, y = boxes[2].y + boxes[2].w/6.5 + boxes[2].w/6.5 + boxes[2].w/6 + boxes[2].w/6, wh = boxes[2].w/25, state = false, text = "Remember."}
} 
text = {}
for i,ebox in ipairs(editbox) do
table.insert(text,{})
end
bindKey("backspace", "down", function ()
  table.remove(text[eboxClickI], #text[eboxClickI])
end)
function getCharacter(character)
  for i,ebox in ipairs(editbox) do
    if eboxClickI == i then
      table.insert(text[i], character)
    end
  end
end
function renderLoginPanel()
	dxDrawImage ( screenWidth/32.95 - 50, 0, 1601, 1201, 'background.jpg' )
	--dxDrawText ( "If you can't log in after registering, try another username.", 330, screenHeight - 370, screenWidth, screenHeight, tocolor ( 255, 255, 255, 255 ), 1, "bankgothic" )
	--dxDrawImage ( sW/2 - logoW/2 + mX, boxes[1].y - logoH - sH/50 + mY, logoW, logoH, 'logo.png')
    --dxDrawImage ( sW/2 - logoW/2 + mX, boxes[1].y - logoH - sH/50 + mY + sH, logoW, logoH, 'logo.png')
	
    for i,box in ipairs(boxes) do
        dxDrawRectangle(box.x + mX, box.y + mY, box.w, box.h)
        dxDrawRectangle(box.x + mX, box.y + mY, box.w, 1, box.borderColor)
        dxDrawRectangle(box.x + mX, box.y + mY, 1, box.h, box.borderColor)
        dxDrawRectangle(box.x + mX, box.y + box.h + mY, box.w, 1, box.borderColor)
        dxDrawRectangle(box.x + box.w + mX, box.y + mY, 1, box.h, box.borderColor)
    if box.boxD then
      if box.boxD == "green" then
      dxDrawRectangle(box.x + mX, box.y + mY, sW/160, box.h, tocolor(13, 151, 82))
      elseif box.boxD == "red" then
      dxDrawRectangle(box.x + mX, box.y + mY, sW/160, box.h, tocolor(13, 151, 82))
    end
    end
    if box.text then
    	dxDrawText ( box.text, box.x + sW/80 + mX, box.y + mY, box.x + box.w + mX, box.y + box.h + mY, tocolor(31,31,31), sW/1600, myFont, "left", "center")
    end
    end
    for i,ebox in ipairs(editbox) do
      dxDrawRectangle(ebox.x + mX, ebox.y + mY, ebox.w, ebox.h)
      dxDrawRectangle(ebox.x + mX, ebox.y + mY, ebox.w, 1, ebox.borderColor)
      dxDrawRectangle(ebox.x + mX, ebox.y + mY, 1, ebox.h, ebox.borderColor)
      dxDrawRectangle(ebox.x + mX, ebox.y + ebox.h + mY, ebox.w, 1, ebox.borderColor)
      dxDrawRectangle(ebox.x + ebox.w + mX, ebox.y + mY, 1, ebox.h, ebox.borderColor)
      if ebox.textUp then
        dxDrawText ( ebox.textUp, ebox.x + mX, ebox.y - ebox.h + mY, ebox.x + ebox.w + mX, ebox.y + mY, tocolor(31,31,31), sW/1600, myFont, "left", "bottom")
      end
      if isMouseWithinRangeOf(ebox.x + mX, ebox.y + mY, ebox.w, ebox.h) then
        ebox.borderColor = tocolor(13, 151, 82)
      else
        ebox.borderColor = tocolor(13, 151, 82)
      end
      if ebox.text then
        ebox.text = table.concat(text[i],"")
        if ebox.hide == true then
        dxDrawText (string.rep("•",#text[i],""), ebox.x + 10 + mX, ebox.y + mY, ebox.x + ebox.w + mX, ebox.y + ebox.h + mY, tocolor(31,31,31), sW/1600, myFont, "left", "center", true)
        else
        dxDrawText ( table.concat(text[i],""), ebox.x + 10 + mX, ebox.y + mY, ebox.x + ebox.w + mX, ebox.y + ebox.h + mY, tocolor(31,31,31), sW/1600, myFont, "left", "center",true)
      end
      end
      if eboxClickI == i then
        dxDrawRectangle(ebox.x + mX, ebox.y + mY, ebox.w, 1, tocolor(13, 151, 82))
        dxDrawRectangle(ebox.x + mX, ebox.y + mY, 1, ebox.h, tocolor(13, 151, 82))
        dxDrawRectangle(ebox.x + mX, ebox.y + ebox.h + mY, ebox.w, 1, tocolor(13, 151, 82))
        dxDrawRectangle(ebox.x + ebox.w + mX, ebox.y + mY, 1, ebox.h, tocolor(13, 151, 82))
      end
    end
    for i,cbox in ipairs(checkboxs) do
      if cbox.state == true then
        dxDrawRectangle(cbox.x + mX, cbox.y + mY, cbox.wh, cbox.wh, tocolor(13, 151, 82))
      else
        dxDrawRectangle(cbox.x + mX, cbox.y + mY, cbox.wh, cbox.wh, tocolor(200,200,200))
      end
      if cbox.text then
        dxDrawText (cbox.text, cbox.x + cbox.wh + 5 + mX, cbox.y + mY, cbox.x + cbox.wh*10 + mX, cbox.y + cbox.wh + mY, tocolor(31,31,31), sW/2000, myFont, "left", "center",true)
      end
    end
end
addEventHandler("onClientCharacter", getRootElement(), getCharacter)
function pressLogin()
  for i, ebox in ipairs(editbox) do
    if ebox.name == "username" then
      gUser = ebox.text
    elseif ebox.name == "password" then
      gPass = ebox.text
    end
  end 
triggerServerEvent ( "onLogin", getLocalPlayer(), gUser, gPass, checkboxs[1].state)
end
function pressRegister()
  for i, ebox in ipairs(editbox) do
    if ebox.name == "usernameReg" then
      rUser = ebox.text
    elseif ebox.name == "passwordReg" then
      rPass = ebox.text
    end
  end 
triggerServerEvent ( "onRegister", getLocalPlayer(), rUser, rPass)
end
function pressRegisterBut()
  p_Move = {}
  p_Move.startTime = getTickCount()
  p_Move.endTime = p_Move.startTime + 1200
  p_Move.easingFunction = "InOutQuad"
  addEventHandler("onClientRender", getRootElement(), movePanelOut)
end
function pressBack()
  p_Move = {}
  p_Move.startTime = getTickCount()
  p_Move.endTime = p_Move.startTime + 1200
  p_Move.easingFunction = "InOutQuad"
  addEventHandler("onClientRender", getRootElement(), movePanelIn)
end
addEvent("pressBack",true)
addEventHandler("pressBack",getRootElement(),pressBack)
function movePanelOut()
  local now = getTickCount()
  local elapsedTime = now - p_Move.startTime
  local duration = p_Move.endTime - p_Move.startTime
  local progress = elapsedTime / duration
 
  local fAnimationTime = getEasingValue(progress, p_Move.easingFunction)
 
  local move = fAnimationTime*sH
  mY = ( -move )
  if now > p_Move.endTime then
    removeEventHandler("onClientRender", getRootElement(), movePanelOut)
  end
end
function movePanelIn()
  local now = getTickCount()
  local elapsedTime = now - p_Move.startTime
  local duration = p_Move.endTime - p_Move.startTime
  local progress = elapsedTime / duration
 
  local fAnimationTime = getEasingValue(progress, p_Move.easingFunction)
 
  local move = fAnimationTime*sH
  mY = (-sH + move)
  if now > p_Move.endTime then
    removeEventHandler("onClientRender", getRootElement(), movePanelIn)
  end
end
function renderButtons()
    for i,b in ipairs(buttons) do
	    dxDrawRectangle(b.x + mX,b.y + mY,b.w,b.h,b.color)
	    dxDrawRectangle(b.x + mX, b.y + mY, b.w, 1, b.borderColor)
      dxDrawRectangle(b.x + mX, b.y + mY, 1, b.h, b.borderColor)
      dxDrawRectangle(b.x + mX, b.y + b.h + mY, b.w, 1, b.borderColor)
      dxDrawRectangle(b.x + b.w + mX, b.y + mY, 1, b.h, b.borderColor)
      if b.text then
        dxDrawText ( b.text, b.x + mX, b.y + mY, b.x + b.w + mX, b.y + b.h + mY, tocolor(31,31,31), sW/1600, myFont, "center", "center")
      end
	    if isMouseWithinRangeOf(b.x + mX, b.y + mY, b.w, b.h) then
		   dxDrawRectangle(b.x + mX,b.y + mY,b.w,b.h,tocolor(13, 151, 82))
		   if b.text then
        	dxDrawText ( b.text, b.x + mX, b.y + mY, b.x + b.w + mX, b.y + b.h + mY, tocolor(255,255,255), sW/1600, myFont, "center", "center")
           end
	    end
    end
end

function changeMessage(mesBox, newMessage, boxColor)
  for i,box in ipairs(boxes) do
    if box.messageBox ==  mesBox then
      box.text = newMessage
      box.boxD = boxColor
    end
  end
end
addEvent("changeMessage",true)
addEventHandler("changeMessage",getRootElement(),changeMessage)
function onClick(mButton,state,ax,ay)
  if not (state == "down" and mButton == "left") then
    return false
  end
  for i,b in pairs(buttons) do
    if isMouseWithinRangeOf(b.x + mX, b.y + mY, b.w, b.h) then
      outputDebugString("Pressed "..b.text)
      if b.func then
      loadstring("return "..b.func.."()")()
      end
    end
  end
  for i,ebox in pairs(editbox) do
    if isMouseWithinRangeOf(ebox.x + mX, ebox.y + mY, ebox.w, ebox.h) then
      outputDebugString("Pressed "..ebox.textUp)
      eboxClickI = i
      return true
    end
  end
  for i,cbox in pairs(checkboxs) do
    if isMouseWithinRangeOf(cbox.x + mX, cbox.y + mY, cbox.wh, cbox.wh) then
      outputDebugString("Pressed "..i.." checkbox")
      if cbox.state == false then
      cbox.state = true
      else
      cbox.state = false
      end
    end
  end
  eboxClickI = nil
  return false
end

addEventHandler("onClientClick",getRootElement(),onClick)

function isMouseWithinRangeOf(posX, posY, sizeX, sizeY)
  if isCursorShowing() == false then
    return false
  end
  local cx,cy = getCursorPosition()
  cx,cy = cx*sW,cy*sH
  if cx >= posX and cx <= posX+sizeX and cy >= posY and cy <= posY+sizeY then
    return true,cx,cy
  else
    return false
  end
end


function hideLoginPanel()
  p_Move = {}
  p_Move.startTime = getTickCount()
  p_Move.endTime = p_Move.startTime + 1200
  p_Move.easingFunction = "InOutQuad"
  addEventHandler("onClientRender", getRootElement(), hidePanelOut)
end
function hidePanelOut()
  local now = getTickCount()
  local elapsedTime = now - p_Move.startTime
  local duration = p_Move.endTime - p_Move.startTime
  local progress = elapsedTime / duration
 
  local fAnimationTime = getEasingValue(progress, p_Move.easingFunction)
 
  local move = fAnimationTime*sH
  mY = move
  bgY = move

  if now > p_Move.endTime then
    removeEventHandler("onClientRender", getRootElement(), hidePanelOut)
    removeEventHandler("onClientRender",getRootElement(),renderLoginPanel)
    removeEventHandler("onClientRender",getRootElement(),renderButtons)
    showCursor(false,false)
    toggleAllControls(true)
    showChat(true)
  end
end
addEvent("hideLoginPanel",true)
addEventHandler("hideLoginPanel",getRootElement(),hideLoginPanel)