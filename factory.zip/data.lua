﻿-- Si deseas agregar mas marcadores o mas peds, solo copias, pegas y cambias las coordenadas y datos
-- Ej: weps[5] = createMarker ( x, y, z, "cylinder", 1.3, 255, 255, 255, 100)
-- Ej: { x, y, z, rotacion Z, skin ID, "strip", "STR_B2C", 0, 0}, 

--Marcadores de venta

weps = {} -- x, y, z, tipo de marcador, tamaño, r, g, b, alpha
weps[1] = createMarker ( 2795.9841308594,-2493.9929199219,12.640270233154, "cylinder", 1.3, 255, 255, 255, 100 )
weps[2] = createMarker ( 1092.4348144531,2095.7124023438,14.350400924683, "cylinder", 1.3, 255, 255, 255, 100 )
weps[3] = createMarker ( -1712.3657226563,7.2531423568726,2.5546875, "cylinder", 1.3, 255, 255, 255, 100 )

-- Peds

factoryPeds = { -- x, y, z, rotacion, skin, animacion tipo, animacion nombre, interior, dimension
    {-1713.9384765625, 5.7265625, 3.5777397155762, 312.23, 269, "gangs", "prtial_gngtlkF", 0,0},
    {1094.6759033203, 2095.6794433594, 15.350400924683, 90, 269, "gangs", "prtial_gngtlkF", 0,0},
    {2798.8322753906,-2494.0502929688,13.636793136597, 90, 269, "gangs", "prtial_gngtlkF", 0,0},
    {-2129.2080078125,-119.38964080811,36.68593597412, 236.41, 237, "strip", "strip_E", 0, 0},
    {-2122.48828125,-119.45358276367,36.685935974121, 180, 87, "strip", "STR_B2C", 0, 0}, 
}

-- Armas para fabricar
armasDisponibles = { -- id del Name, Ammout, Price
	{22, 30, 150},
	{16, 1, 500},
    {25, 16, 250},
    {26, 10, 250},
    {32, 150, 350},
    {28, 150, 400},
    {30, 150, 2000},
    {31, 150, 2000},
    {33, 20, 600},
    {34, 20, 4000},
    {27, 20, 1000},
    {24, 20, 1000},
    {29, 120, 1000},
	{10, 1, 250},
	{5, 1, 250}
}

-- Aqui puedes cambiar el texto que sale en la ventana de Weapons Factroy
memoTexto = "Welcome too Ammo Factroy Click on Any Wepaons and prees Create."

-- Aqui puedes modificar el nombre de la ventana
ventanaName = "Weapos Factory"