local screenWidth, screenHeight = guiGetScreenSize()
local jobs = {
	{"Bus Driver", "As a bus driver, a player is required to drive a bus through an assigned route, stopping at paricular spots termed as bus stops on the way. The occupation may be opted for only in Los Santos. In order to become employed as a bus driver, a player must walk into the bus driver job marker found in LS near the Santa Maria Beach. Once you've stood in the marker, a GUI pops up where you are to select your skin for the job from a list. After doing so, you've  successfully been recruited as a bus driver and you will see a bus spawner nearby around you. Once you've walked into it, another GUI pops up to allow you to make a selection of your desired vehicle. After spawning a bus for the job, you're all set for your long trip across the roads of Los Santos. You will be guided to your destinations during your journey by location blips that appear on your radar. Reaching a bus stop will earn you cash each time. The amount of pay you get for reaching each stop depends on the length of road you've covered to get to your destination. Keep in mind that you will have to stop your vehicle at the destinations to receive your pay.\n\nTips: Each time you get employed as a driver, you ought to be ready for a long journey before you can relax. In order to provide yourself with some respite, you should set your vehicle to cruise at around 60 kph since you will only occasionally need to brake your speed at stops. You must always drive on the right lane of the road for a safe and sound journey. Avoid over speeding, as it can ultimately lead to your bus going out of control more often and becoming harder to stop. Remember that the huger a vehicle is, the more inertia it carries. Hence, you ought to be very careful with a bus. Bon Voyage!"},
	{"Trucker", "To become a Trucker, you'll need to go to any of the two locations, Ocean Docks in Los Santos just beside the Los Santos Airport or at Easter Basin in San Fierro just beside the San Fierro Airport. You than need to walk into the yellow marker to receive your job. You will have the selection of four skins to choose from, select the skin you prefer to use than click on Have Job. After you get the job, you'd need to spawn any truck at the jobs location. Same as the skins, you will have the selection of trucks to choose from (Linerunner, Roadtrain, Tanker)\n\nAfter you select your truck you'll get your first mission. You'll be told to drive to the blip or marker on your Hud/Minimap. Throughout this job there will be numerous amount of missions all around San Andreas to be complete, they will also be jumbled up so you might go to the same location. As for your pay, it will be set out from the distances you have been driving in. The further the next delivery point, the more pay you will receive.\n\nGood luck with your job, have fun and don't break any rules whilst driving."},
	{"Medic", "To get the medic job, you can take it at All Saints Hospital (LS), General Hospital (LS) or SF hospital (SF). Once you have taken the job, you must heal people by spraying them with a spray can. To find people, press F5 and mark players that have low health. You can change what kind of people come up by using one of the options below the grid list. To make them, select there name and press the Mark button. A red cross will appear on your map which will be the person you have marked. You will get a certain amount for healing them, depending how much health they have. You can also heal them by getting them into your ambulance. You can spawn one at the job location."},
	{"Pilot", "To become a pilot, you must walk into the pilot job marker at an airport in San Andreas. You may go to the Los Santos Airport across the Southern shore of the city (LS), The Las Venturas Airport in the middle of the town that homes mafia wars (LV), or the San Fierro Airport by the Eastern shore of SF. After you've walked into a marker, you will be prompted to select the pilot skin you desire. Once you have been employed as a pilot, you must go into the respective airport's landing/takeoff zone. Near the runway, you will find several markers that act as aircraft spawners for pilots. Walk into one of the markers and select your preffered aircraft. Once you're done with the selection, you're all ready for take off. You'll see a truck blip on your radar which indicates your destination which usually will be among one of the three airports and the Abandoned Airstrip in the Northern part of LV in the middle of the desert. Flying to different destinations and landing on a marker that you see at the position of the radar blip will earn you a particular amount, depending on the distance you've flown to get to your destination. You will advance in rank as a pilot as your number of flights progress. The higher your rank is, the more pay will you get off each flight and a wider variety of aircrafts will be available for you to pilot.\n\nTips: Try to keep a certain height when flying to evade obstacles like sky scrapers and trees easily. Always fly safe if you're a beginner and don't try to push it with the stunts (e.g. flying your aircraft upside down as a rookie). Brake your aircraft's speed as soon as you see the yellow runway indicator flashing across your radar in order to make your landing safer and easier. Happy Trails!"},
	{"Hooker", "Oh I know your dirty minds at the moment. Anyways JUST in case you don't know how this works. Yes this job is made to have sex with other players. The cool thing about it - you will get paid for it. Simply take the Hooker Job and get into someones vehicle as a passenger. Would be nice ofcourse, if you could ask the owner before just jumping in, if he even wants to have sex or if he is happily married or something. However as soon as you will get into the vehicle a gui will appear for the driver and he will choose the 'option' he wants. He will be able to choose between various options and yes you will have to do anything he wants. After finishing your job you will get paid and can search for other 'customers'. Ofcourse the money you will get, will depend on the option the vehicle driver has choosen before."},
	{"Fisher Man", "One can be employed as a fisher man from a marker found on the West coast of San Fierro. Once you've equipped a fisher man skin from a GUI that pops up onto the screen, you are to go over to the dock and jump into the marker found in the water. Once in it, another GUI appears where one is supposed to select the desired boat from a pre designed list before venturing off into the vast open sea for merchandise. After you've selected the boat, you're all set to sail into the horizon. Roll away from the docks and stay in the open sea for some time, during which you will be prompted if you've caught any fish. You'll need to change your location everytime you get fish from a particular spot. Every shoal of fish you get earns you a particular amount of cash. Once you think you've got enough catch, head back to the docks to call it a day.\n\nTips: Be sure to stay at spots in the sea long enough till a message tells you you've cauht fish from the spot. In order to get more fish, you will have to change spots each time you've caught something. Remeber, sailing isn't quite similar to driving, so be careful when sailing, paying particular attention to the braking distance you'll need each time to bring your boat to a stop. Bon Voyage!"},
	{"Taxi Driver", "Transportation is the key to getting to know the streets of San Andreas well. As a Taxi Driver, you are to aid random pedestrians in getting to their specified destinations. The Taxi Driver job marker may be found either in Los Santos or in San Fierro. Once you've walked into a marker, a GUI appears on the screen, prompting you to select your desired taxi driver skin from a pre assigned list. After doing so, a vehicle spawner may be located near your position. Walk into the spawner and choose your preffered cab from another list in a second GUI that pops up on to your screen. Once you've spawned a cab, you're all set to drive off and pick up pedestrians that need a lift. Those that do appear on your radar as blips. Get to the blip and stand beside the pedestrian to get him/her into your vehicle. Once you've picked up a pedestrian, another location blip may be seen on the radar. Drive the pedestrian to the specified destination and once you've reached it, stop your car in the destination marker to get your pay for transporting the ped. You may pick up as many more pedestrians as you desire and drop them off at their specified locations for a certain fee.\n\nTips: Always drive safe and stay in your lane of the road (the right hand lane). Never overspeed if you want to keep your vehicle's health at a maximum. In order to receive your pay for dropping a ped somewhere off, you don't just need to drive through a destination marker, but stop your cab in it and wait till you see a message that says you've received your pay. Happy trails!"},
	{"Mechanic", "As a mechanic, you are required to fix damaged cars for a certain fee. The pay you receive from fixing a vehicle depends on the health of the car at the time you fixed it. The more damaged a car is, the more cash you receive for fixing it. The fee is deducted from the vehicle owner's cash and added to the respective mechanic's funds. The mechanic job can be found in each of the three cities of San Andreas. In LS, you can find it next to the Pay'n'Spray garage near the LS bank. In SF, the job marker may be located near the Pay'n'Spray garage in Doherty behind the car showroom. In LV, one can become a mechanic by walking into a job marker found beside the Pay'n'Spray garage near the LV Hospital. After a player walks into a mechanic job marker, a GUI appears on the screen where one can select his/her desired mechanic skin from a list. Once the skin has been selected, you have successfully been employed as a mechanic. Somewhere near the job marker, a yellow vehicle spawner will appear where the newly employed mechanic can select a vehicle of his/her choice. The procedure for selecting the vehicle is similar to that for selecting a mechanic skin (using a GUI that pops up after walking into the spawner). \n\nAfter becoming employed as a mechanic, you must find a vehicle to fix around you. Once you see it, or someone finds you and demands a repair, you must stand beside the damaged vehicle and tap the right mouse button while looking at the affected vehicle to request the vehicle's owner to allow you to repair the vehicle. Upon receiving the owner's consent, your player will take a certain amount of time to fix the vehicle before the car becomes as good as new and you receive your pay.\n\nTip: If you look forward to repairing a lot of vehicles, fulfill your duty at one of the vehicle recovery spots around SA. These are the spots where you'll find the most number of eager customers."},
	{"Criminal", "Being a criminal is easy as counting to 10, all you need to do is type in /criminal on the Main Chat. Being a criminal is a easy but complicated life. Criminals deal with Turfs, Robs, Stabbings, Shootings and other crime related things. A criminals main task is to run away from the police; attack the police (please be wanted before you DM a police officer); Robbing banks, cars, players and turfing/dealing with weapons etc.\n\nBeing a criminal doesn't mean you can DM people in LS or SF, that is against the UIP Rules and you will be punished for those actions."},
	{"Police Officer", "To become an officer, go to any one of the 3 major Police Departments (LSPD, SFPD, LVPD) in San Andreas. After you get the job, you will be given a police baton (Nightstick) to arrest wanted players. For arresting any wanted scum you first have to send him a surrender warning by pressing 'M'. If he surrenders there you get him under arrest and must bring him to the blue blip on your radar. If he decides to escape you have to beat him up with your nigh-stick until he comes under arrest. Your payment for arresting depends on the wanted level of the offender."},
}

function createBusiness()
	windowWidth, windowHeight = 325, 475
	windowX, windowY = (screenWidth / 1) - (windowWidth / 1), (screenHeight / 2) - (windowHeight / 2)
	jobWindow = guiCreateWindow(windowX, windowY, windowWidth, windowHeight, "", false)
	jobClose = guiCreateButton(9, 428, 83, 32, "Exit", false, jobWindow)
	jobHave = guiCreateButton(229, 428, 83, 32, "Have Job", false, jobWindow)
	jobDescription = guiCreateLabel(8, 28, 304, 308, "Description", false, jobWindow)
	guiSetVisible(jobWindow,  true)
	jobGrid = guiCreateGridList(9, 307, 302, 111, false, jobWindow)
	jobColumn = guiGridListAddColumn(jobGrid, "Skin ID", 0.8)
	guiSetFont(jobDescription, "clear-normal")
	guiSetAlpha(jobWindow, 1)
	guiSetVisible(jobWindow, false)
	
	--Events
	addEventHandler("onClientGUIClick", jobGrid, viewTheSkin, false)
	addEventHandler("onClientGUIClick", jobHave, selectedJob, false)
	addEventHandler("onClientGUIClick", jobClose, function () guiSetVisible(jobWindow, false) showCursor(false) setElementModel(localPlayer, model) end, false)
end
addEventHandler("onClientResourceStart", resourceRoot, createBusiness)

function createManagmentWindow()
	windowWidth, windowHeight = 612, 463
	windowX, windowY = (screenWidth / 2) - (windowWidth / 2), (screenHeight / 2) - (windowHeight / 2)
	managmentWindow = guiCreateWindow(windowX, windowY, windowWidth, windowHeight, "Job Management", false)
	employmentLabel = guiCreateLabel(9, 26, 231, 23, "Current Employment: ", false, managmentWindow)
	guiSetFont(employmentLabel, "clear-normal")
	guiSetAlpha(managmentWindow, 1)
	employmentGridlist = guiCreateGridList(9, 48, 127, 360, false, managmentWindow)
	employmentColumn = guiGridListAddColumn(employmentGridlist, "Jobs", 0.65)
	employmentMemo = guiCreateMemo(138, 49, 458, 358, "", false, managmentWindow)
	guiMemoSetReadOnly(employmentMemo, true)
	closeButtonEmployment = guiCreateButton(13, 421, 583, 30, "Close", false, managmentWindow)
	dutyButtonEmployment = guiCreateButton(480, 20, 122, 28, "End/Start Duty", false, managmentWindow)
	resignButtonEmployment = guiCreateButton(345, 21, 125, 28, "Resign", false, managmentWindow)
	guiSetVisible(managmentWindow, false)
	
	for index, val in pairs(jobs) do
		local row = guiGridListAddRow(employmentGridlist)
		guiGridListSetItemText(employmentGridlist, row, employmentColumn, val[1], false, false)
	end
	
	--Events
	addEventHandler("onClientGUIClick", closeButtonEmployment, function () guiSetVisible(managmentWindow, false) showCursor(false) end, false)
	addEventHandler("onClientGUIClick", dutyButtonEmployment, dutyClicked, false)
	addEventHandler("onClientGUIClick", resignButtonEmployment, resignClicked, false)
	addEventHandler("onClientGUIClick", employmentGridlist, clickedGridlist, false)
end
addEventHandler("onClientResourceStart", resourceRoot, createManagmentWindow)

function enteredMarker(name, description, skins)
	guiSetVisible(jobWindow, true)
	guiGridListClear(jobGrid)
	guiSetText(jobWindow, name)
	guiSetText(jobDescription, description)
	showCursor(true)
	jobName = name
	jobskins = skins
	model = getElementModel(localPlayer)
	if (not skins) then
		guiSetVisible(jobGrid, false)
		noSkin = true
		return
	else
		guiSetVisible(jobGrid, true)
		noSkin = nil
	end
	for index, skin in pairs(skins) do
		local row = guiGridListAddRow(jobGrid)
		guiGridListSetItemText(jobGrid, row, jobColumn, tostring(skin), false, true)
	end
end
addEvent("UIPbusiness.showManagmentInfo", true)
addEventHandler("UIPbusiness.showManagmentInfo", root, enteredMarker)

function viewTheSkin()
	if (guiGridListGetSelectedItem(jobGrid) == -1) then return end
	local row = guiGridListGetSelectedItem(source)
	local skin = guiGridListGetItemText(jobGrid, row, jobColumn)
	setElementModel(localPlayer, skin or 0)
end

function selectedJob()
	local skin = getElementModel(localPlayer)
	for index, s in pairs(jobskins) do
		if (skin ~= s) then
			if (skin == 0 or skin == model and not noSkin) then
				setElementModel(localPlayer, model)
				exports.UIPtexts:output("You must select a skin from the list!", 255, 0, 0)
				return
			end
		end
	end
	guiSetVisible(jobWindow, false)
	showCursor(false)
	setElementModel(localPlayer, model)
	if (noSkin) then
		skin = false
	end
	triggerServerEvent("UIPbusiness.acceptJob", root, jobName, skin)
end

function bindEmployment()
	guiSetVisible(managmentWindow, not guiGetVisible(managmentWindow))
	showCursor(not isCursorShowing())
	if (guiGetVisible(managmentWindow)) then
		local occupation = getElementData(localPlayer, "Occupation")
		guiSetText(employmentLabel, "Current Employment: "..occupation)
	end
end
bindKey("F3", "down", bindEmployment)

function clickedGridlist()
	if (guiGridListGetSelectedItem(employmentGridlist) == -1) then return end
	local row = guiGridListGetSelectedItem(source)
	local theJob = guiGridListGetItemText(employmentGridlist, row, employmentColumn)
	for index, val in pairs(jobs) do
		if (theJob == val[1]) then
			guiSetText(employmentMemo, val[2])
		end
	end
end

function dutyClicked()
	local occupation = getElementData(localPlayer, "Occupation")
	triggerServerEvent("UIPbusiness.duty", root, occupation)
end

function resignClicked()
	local occupation = getElementData(localPlayer, "Occupation")
	triggerServerEvent("UIPbusiness.resign", root, occupation)
end