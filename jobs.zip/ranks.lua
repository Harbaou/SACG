local screenWidth, screenHeight = guiGetScreenSize()
local state = false
local theString = {}

function drawWindow()
	dxDrawText(theString[1], 583.0, 529.0, 1356.0, 585.0, tocolor(255, 255, 255, 255), 1.3, "default-bold", "center", "top", false, false, true)
	dxDrawText(theString[2], 583.0, 585.0, 1356.0, 641.0, tocolor(255, 255, 255, 255), 1.3, "default-bold", "center", "top", false, false, true)
	dxDrawText(theString[3], 579.0, 463.0, 1352.0, 519.0, tocolor(255, 255, 255, 255), 1.3, "default-bold", "center", "top", false, false, true)
	dxDrawText("My Rank: ", 579.0, 407.0, 1352.0, 463.0, tocolor(255, 255, 255, 255), 1.3, "default-bold", "center", "top", false, false, true)
	dxDrawText(theString[4], 579.0, 351.0, 1352.0, 407.0, tocolor(255, 255, 255, 255), 1.3, "default-bold", "center", "top", false, false, true)
	dxDrawLine(579.0, 337.0, 1346.0, 337.0, tocolor(255, 255, 255, 255), 1.0, false)
	dxDrawText("UIP Business Center", 578.0, 298.0, 1352.0, 333.0, tocolor(255, 255, 255, 255), 1.2, "sans", "center", "center", false, false, true)
	dxDrawRectangle(578.0, 298.0, 769.0, 370.0, tocolor(0, 0, 0, 210), false)
end

function toggleWindow()
	state = not state
	if (state) then
		triggerServerEvent("UIPbusiness.getInfoEvent", root)
	else
		removeEventHandler("onClientRender", root, drawWindow)
	end
end
--bindKey("F5", "down", toggleWindow)

function updateInfo(val1, val2, amount, earned)
	theString[1] = "Current Payment: $"..val1.." from "..val2.." mission(s)"
	local earned = earned or 0
	local amount = amount or 0
	local myJob = getElementData(localPlayer, "Occupation") or "N/A"
	theString[2] = "All Time Payment: $"..earned
	theString[3] = "Job Progress: "..amount
	theString[4] = "My Employment: "..myJob
	addEventHandler("onClientRender", root, drawWindow)
end
addEvent("UIPbusiness.updateInfo", true)
addEventHandler("UIPbusiness.updateInfo", root, updateInfo)