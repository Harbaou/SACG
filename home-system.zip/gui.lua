addEventHandler("onClientResourceStart",getResourceRootElement(getThisResource()),
function()
  theHouseGUIWindow = guiCreateWindow(0.3088,0.275,0.3925,0.3433,"Home system by JasperNL=D",true)
  guiWindowSetMovable(theHouseGUIWindow,false)
  guiWindowSetSizable(theHouseGUIWindow,false)
  guiSetVisible (theHouseGUIWindow,false)
  theHouseGUIEnterButton = guiCreateButton(0.0446,0.7816,0.2771,0.1748,"Enter house",true,theHouseGUIWindow)
  theHouseGUIBuyButton = guiCreateButton(0.3567,0.7816,0.2771,0.1748,"Buy house",true,theHouseGUIWindow)
  theHouseGUISellButton = guiCreateButton(0.6688,0.7816,0.2771,0.1748,"Sell house",true,theHouseGUIWindow)
  theHouseGUICloseButton = guiCreateButton(0.9172,0.1165,0.0541,0.0777,"x",true,theHouseGUIWindow)
  theHouseGUIOwnerLabel = guiCreateLabel(0.0255,0.165,0.3854,0.1214,"Owner",true,theHouseGUIWindow)
  guiLabelSetColor(theHouseGUIOwnerLabel,255,255,255)
  guiLabelSetVerticalAlign(theHouseGUIOwnerLabel,"center")
  guiLabelSetHorizontalAlign(theHouseGUIOwnerLabel,"left",false)
  theHouseGUINumberLabel = guiCreateLabel(0.0255,0.5194,0.3854,0.1214,"House Number",true,theHouseGUIWindow)
  guiLabelSetColor(theHouseGUINumberLabel,255,255,255)
  guiLabelSetVerticalAlign(theHouseGUINumberLabel,"center")
  guiLabelSetHorizontalAlign(theHouseGUINumberLabel,"left",false)
  theHouseGUIPriceLabel = guiCreateLabel(0.0255,0.3447,0.3854,0.1214,"House Price",true,theHouseGUIWindow)
  guiLabelSetColor(theHouseGUIPriceLabel,255,255,255)
  guiLabelSetVerticalAlign(theHouseGUIPriceLabel,"center")
  guiLabelSetHorizontalAlign(theHouseGUIPriceLabel,"left",false)
  theHouseGUIOwnerInfoLabel = guiCreateLabel(0.5,0.165,0.3854,0.1214,"-- Owner --",true,theHouseGUIWindow)
  guiLabelSetColor(theHouseGUIOwnerInfoLabel,255,255,255)
  guiLabelSetVerticalAlign(theHouseGUIOwnerInfoLabel,"center")
  guiLabelSetHorizontalAlign(theHouseGUIOwnerInfoLabel,"left",false)
  theHouseGUIPriceInfoLabel = guiCreateLabel(0.5478,0.3447,0.3854,0.1214,"-- House Price --",true,theHouseGUIWindow)
  guiLabelSetColor(theHouseGUIPriceInfoLabel,255,255,255)
  guiLabelSetVerticalAlign(theHouseGUIPriceInfoLabel,"center")
  guiLabelSetHorizontalAlign(theHouseGUIPriceInfoLabel,"left",false)
  theHouseGUINumberInfoLabel = guiCreateLabel(0.5032,0.5194,0.3854,0.1214,"-- House Number -- ",true,theHouseGUIWindow)
  guiLabelSetColor(theHouseGUINumberInfoLabel,255,255,255)
  guiLabelSetVerticalAlign(theHouseGUINumberInfoLabel,"center")
  guiLabelSetHorizontalAlign(theHouseGUINumberInfoLabel,"left",false)
  theHouseGUIDollarLabel = guiCreateLabel(0.5,0.3447,0.0446,0.1214,"$",true,theHouseGUIWindow)
  guiLabelSetColor(theHouseGUIDollarLabel,255,255,255)
  guiLabelSetVerticalAlign(theHouseGUIDollarLabel,"center")
  guiLabelSetHorizontalAlign(theHouseGUIDollarLabel,"left",false)
end)

addEvent ("viewHouseGUIwindow",true)
addEventHandler ("viewHouseGUIwindow",getRootElement(),
function(owner,price,housenumber)
  if (source == getLocalPlayer()) then
    guiSetText (theHouseGUIOwnerInfoLabel,owner)
    guiSetText (theHouseGUIPriceInfoLabel,price)
    guiSetText (theHouseGUINumberInfoLabel,housenumber)
    guiSetVisible (theHouseGUIWindow,true)
    showCursor (true,true)
  end
end)

addEventHandler ("onClientGUIClick",getRootElement(),
function(button,state,absX,absY)
  if (source == theHouseGUICloseButton) then
    guiSetVisible (theHouseGUIWindow,false)
    showCursor (false,false)
  elseif (source == theHouseGUIEnterButton) then
    local housenumber = guiGetText (theHouseGUINumberInfoLabel)
    triggerServerEvent ("HouseSystemEnterHouse",getLocalPlayer(),housenumber)
  elseif (source == theHouseGUIBuyButton) then
    local housenumber = guiGetText (theHouseGUINumberInfoLabel)
    triggerServerEvent ("HouseSystemBuyHouse",getLocalPlayer(),housenumber)
  elseif (source == theHouseGUISellButton) then
    local housenumber = guiGetText (theHouseGUINumberInfoLabel)
    triggerServerEvent ("HouseSystemSellHouse",getLocalPlayer(),housenumber)
  end
end)

addEvent ("hideHouseGuiWindow",true)
addEventHandler("hideHouseGuiWindow",getRootElement(),
function()
  if (source == getLocalPlayer()) then
    guiSetVisible (theHouseGUIWindow,false)
    showCursor (false,false)
  end
end)