gResRoot = getResourceRootElement(getThisResource())
function loadAllHouses ()
  local root = xmlLoadFile ("homes.xml")
  local houseroot = xmlFindChild (root,"houses",0)
  if (houseroot) then
    allHouses = {}
    for i,v in ipairs (xmlNodeGetChildren(houseroot)) do
      local x = xmlNodeGetAttribute (v,"x")
      local y = xmlNodeGetAttribute (v,"y")
      local z = xmlNodeGetAttribute (v,"z")
      local number = xmlNodeGetAttribute (v,"num")
      if not (xmlNodeGetAttribute (v,"owner") == "") then
        local marker = createMarker (tonumber(x),tonumber(y),tonumber(z),"corona",1,255,0,0,getRootElement())
        setElementData (marker,"housenumber",tonumber(number))
      else
        local marker = createMarker (tonumber(x),tonumber(y),tonumber(z),"corona",1,0,255,0,getRootElement())
        setElementData (marker,"housenumber",tonumber(number))
      end
      outputDebugString ("House " .. tostring(number) .. " loaded!")
    end
  end
end
addEventHandler("onResourceStart",gResRoot, loadAllHouses)

addEventHandler ("onMarkerHit",getRootElement(),
function(hitElement, dimension)
  if (getElementType (hitElement) == "player") and not (isPedInVehicle (hitElement)) then
    if (getElementData (source,"housenumber")) then
      local housenumber = getElementData (source,"housenumber")
      --outputChatBox (tostring(housenumber),hitElement,255,0,0,false)
      local root = xmlLoadFile ("homes.xml")
      local houseHeadRootNode = xmlFindChild (root,"houses",0)
      local houseRootNode = xmlFindChild (houseHeadRootNode,"house",tonumber(housenumber))
      if (tostring(xmlNodeGetAttribute (houseRootNode,"owner")) == "") then
        triggerClientEvent (hitElement,"viewHouseGUIwindow",hitElement,"Nobody!",tostring(xmlNodeGetAttribute (houseRootNode,"cost")),housenumber)
        xmlUnloadFile (root)
      else
        triggerClientEvent (hitElement,"viewHouseGUIwindow",hitElement,tostring(xmlNodeGetAttribute (houseRootNode,"owner")),tostring(xmlNodeGetAttribute (houseRootNode,"cost")),housenumber)
        xmlUnloadFile (root)
      end
    end
  end
end)

addEvent("HouseSystemEnterHouse",true)
addEvent("HouseSystemBuyHouse",true)
addEvent("HouseSystemSellHouse",true)

addEventHandler ("HouseSystemBuyHouse", getRootElement(),
function(housenumber)
  local root = xmlLoadFile ("homes.xml")
  local houseHeadRootNode = xmlFindChild (root,"houses",0)
  local houseRootNode = xmlFindChild (houseHeadRootNode,"house",tonumber(housenumber))  
  local price = xmlNodeGetAttribute (houseRootNode,"cost")
  local owner = xmlNodeGetAttribute (houseRootNode,"owner")
  if not (isGuestAccount (getPlayerAccount(source))) then
    if (owner == "") and (getPlayerMoney (source) >= tonumber(price)) then
      takePlayerMoney (source,tonumber(price))
      xmlNodeSetAttribute (houseRootNode,"owner",getAccountName(getPlayerAccount(source)))
      outputChatBox ("Congratulations, you are the new owner!",source,255,0,0,false)
      outputChatBox ("Price: ".. tostring(price) .. "$!",source,255,0,0,false)
      setMarkerColor (getMarkerByHousenumber(housenumber),255,0,0,255)
      xmlSaveFile (root)
    elseif not (owner == "") then
      outputChatBox ("Sorry, This house is already bought!",source,255,0,0,false)
    elseif (getPlayerMoney (source) < tonumber(price)) then
      outputChatBox ("Sorry, you are too poor!",source,255,0,0,false)
    end
  else
    outputChatBox ("Please log in!",source,255,0,0,false)
  end
  triggerClientEvent (source,"hideHouseGuiWindow",source)
  xmlUnloadFile (root)  
end)

addEventHandler ("HouseSystemSellHouse", getRootElement(),
function(housenumber)
  local root = xmlLoadFile ("homes.xml")
  local houseHeadRootNode = xmlFindChild (root,"houses",0)
  local houseRootNode = xmlFindChild (houseHeadRootNode,"house",tonumber(housenumber))  
  local price = xmlNodeGetAttribute (houseRootNode,"cost")
  local owner = xmlNodeGetAttribute (houseRootNode,"owner")
  if not (isGuestAccount (getPlayerAccount(source))) then
    if (owner == getAccountName(getPlayerAccount(source))) then
      givePlayerMoney (source,tonumber(price)/2)
      xmlNodeSetAttribute (houseRootNode,"owner","")
      outputChatBox ("Congratulations, you have sold the home!",source,255,0,0,false)
      outputChatBox ("Obtain: ".. tostring(price)/2 .. "$!",source,255,0,0,false)
      setMarkerColor (getMarkerByHousenumber(housenumber),0,255,0,255)
      xmlSaveFile (root)
    elseif not (owner == getAccountName(getPlayerAccount(source))) then
      outputChatBox ("This isn't your house!",source,255,0,0,false)
    end
  else
    outputChatBox ("Please log in!",source,255,0,0,false)
  end
  triggerClientEvent (source,"hideHouseGuiWindow",source)
  xmlUnloadFile (root)  
end)

addEventHandler ("HouseSystemEnterHouse",getRootElement(),
function(housenumber)
  local root = xmlLoadFile ("homes.xml")
  local houseHeadRootNode = xmlFindChild (root,"houses",0)
  local houseRootNode = xmlFindChild (houseHeadRootNode,"house",tonumber(housenumber))  
  local x,y,z = getElementPosition (source)
  if (xmlNodeGetAttribute (houseRootNode,"owner") == "") then
    setElementData (source,"posx",x)
    setElementData (source,"posy",y)
    setElementData (source,"posz",z)
    local interiornumber = xmlNodeGetAttribute (houseRootNode,"interior")
    local interiorRootNode = xmlFindChild (xmlFindChild (root,"interiors",0),"interior",tonumber(interiornumber))  
    setElementInterior (source,tonumber(xmlNodeGetAttribute (interiorRootNode,"id")),tonumber(xmlNodeGetAttribute (interiorRootNode,"x")),tonumber(xmlNodeGetAttribute (interiorRootNode,"y")),tonumber(xmlNodeGetAttribute (interiorRootNode,"z")))
    setElementDimension (source,xmlNodeGetAttribute(houseRootNode,"dim"))
    outputChatBox ("Welcome! This house isn't bought yet!",source,255,0,0,false)
    outputChatBox ("Use /leave to leave the house!",source,255,0,0,false)
    triggerClientEvent (source,"hideHouseGuiWindow",source)
  elseif (getAccountName(getPlayerAccount(source)) == xmlNodeGetAttribute (houseRootNode,"owner")) then
    setElementData (source,"posx",x)
    setElementData (source,"posy",y)
    setElementData (source,"posz",z)
    local interiornumber = xmlNodeGetAttribute (houseRootNode,"interior")
    local interiorRootNode = xmlFindChild (xmlFindChild (root,"interiors",0),"interior",tonumber(interiornumber))  
    setElementInterior (source,tonumber(xmlNodeGetAttribute (interiorRootNode,"id")),tonumber(xmlNodeGetAttribute (interiorRootNode,"x")),tonumber(xmlNodeGetAttribute (interiorRootNode,"y")),tonumber(xmlNodeGetAttribute (interiorRootNode,"z")))
    setElementDimension (source,xmlNodeGetAttribute(houseRootNode,"dim"))
    outputChatBox ("Welcome!",source,255,0,0,false)
    outputChatBox ("Use /leave to leave the house!",source,255,0,0,false)
    triggerClientEvent (source,"hideHouseGuiWindow",source)
  elseif not (getAccountName(getPlayerAccount(source)) == xmlNodeGetAttribute (houseRootNode,"owner")) then
    outputChatBox ("You aren't the owner of this home!",source,255,0,0,false)
    outputChatBox ("If you are, make sure you are logged in!",source,255,0,0,false)
  end
  xmlUnloadFile (root)
end)

addCommandHandler ("leave",
function(thePlayer,command)
  if (getElementInterior (thePlayer) ~= 0) and (getElementData (thePlayer,"posx")) and (getElementData (thePlayer,"posy")) and (getElementData (thePlayer,"posz")) then
    setElementPosition (thePlayer,getElementData (thePlayer,"posx"),getElementData (thePlayer,"posy"),getElementData (thePlayer,"posz"))
    setElementInterior (thePlayer,0)
    setElementDimension (thePlayer,0)
    removeElementData (thePlayer,"posx")
    removeElementData (thePlayer,"posy")
    removeElementData (thePlayer,"posz")
  end
end)

addCommandHandler ("createhouse",
function(thePlayer,command,interiorid,dimension,price)
  if (interiorid) and (dimension) and (price) and (not isPedInVehicle(thePlayer)) then
    if (hasObjectPermissionTo (thePlayer,"command.aexec",false)) then
      local x,y,z = getElementPosition (thePlayer)
      local houseCount = tonumber(getHouseCount())
      local root = xmlLoadFile ("homes.xml")
      local housesRoot = xmlFindChild (root,"houses",0)
      local newHouse = xmlCreateChild (housesRoot,"house")
      xmlNodeSetAttribute (newHouse,"num",houseCount)
      xmlNodeSetAttribute (newHouse,"interior",interiorid)
      xmlNodeSetAttribute (newHouse,"x",x)
      xmlNodeSetAttribute (newHouse,"y",y)
      xmlNodeSetAttribute (newHouse,"z",z)
      xmlNodeSetAttribute (newHouse,"cost",price)
      xmlNodeSetAttribute (newHouse,"owner","")
      xmlNodeSetAttribute (newHouse,"dim",dimension) 
      outputChatBox ("The house will appear when you restart the resource!",thePlayer,255,0,0,false)  
      xmlSaveFile (root)   
      xmlUnloadFile (root)   
    else
      outputChatBox ("Admin only!",thePlayer,255,0,0,false)
    end
  else
    outputChatBox ("Wrong syntax, or get out of your vehicle!",thePlayer,255,0,0,false)
    outputChatBox ("SYNTAX: /createhouse [interior ID] [Dimension] [price in $]",thePlayer,255,0,0,false)
    outputChatBox (" Interior ID - standard 0-21 - the standard houses.",thePlayer,255,0,0,false)
    outputChatBox (" Dimension - number between 0 and 65535, always take another each interior!",thePlayer,255,0,0,false)
    outputChatBox (" Price - How much does the home cost?",thePlayer,255,0,0,false)
  end
end)

function getHouseCount ()
  local root = xmlLoadFile ("homes.xml")
  local housesRoot = xmlFindChild (root,"houses",0)
  local allHouses = xmlNodeGetChildren (housesRoot)
  houses = 0
  for i,v in ipairs (allHouses) do
    houses = houses+1
  end
  xmlUnloadFile (root)
  return houses
end 

function getMarkerByHousenumber (housenumber)
  for i,v in ipairs (getElementsByType("marker")) do
    if (getElementData (v,"housenumber") == tonumber(housenumber)) then
      return v
    end
  end
end
