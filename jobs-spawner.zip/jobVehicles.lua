local screenWidth, screenHeight = guiGetScreenSize()
local v_table = {}


function createVehicleChooserGUI()
	if (isElement(wndVehicle)) then
		if (guiGetVisible(wndVehicle)) then return end
	end
	windowWidth, windowHeight = 321, 338
	windowX, windowY = (screenWidth / 2) - (windowWidth / 2), (screenHeight / 2) - (windowHeight / 2)
	wndVehicle = guiCreateWindow(windowX, windowY, windowWidth, windowHeight, "Select Vehicle",false)
	guiSetAlpha(wndVehicle, 1)
	gridVehicle = guiCreateGridList(9,23,303,249,false,wndVehicle)
	vehicleColumn = guiGridListAddColumn(gridVehicle,"Vehicle",0.8)
	vehicleSpawn = guiCreateButton(9,282,96,37,"Select",false,wndVehicle)
	vehicleClose = guiCreateButton(216,282,96,37,"Exit",false,wndVehicle)
	addEventHandler("onClientGUIClick", vehicleSpawn, onPlayerSelectVehicle)
	addEventHandler("onClientGUIClick", vehicleClose, onPlayerExitVehicleGUI)
end

function enteredMarker(vehicles, rotation, posX, posY, posZ, rotation, r, g, b)
	createVehicleChooserGUI()
	v_table[1] = posX
	v_table[2] = posY
	v_table[3] = posZ
	v_table[4] = rotation
	v_table[5] = r
	v_table[6] = g
	v_table[7] = b
	showCursor(true)
	guiGridListClear(gridVehicle)
	for index, vehicles in ipairs(vehicles) do
		vehicleRow = guiGridListAddRow(gridVehicle)
		guiGridListSetItemText(gridVehicle, vehicleRow, vehicleColumn, getVehicleNameFromModel(vehicles), false, true)
	end
end
addEvent("UIPjobvehicles.enteredMarker", true)
addEventHandler("UIPjobvehicles.enteredMarker", root, enteredMarker)

function onPlayerExitVehicleGUI(button, state)
	if (button ~= "left" or state ~= "up") then return end
	guiSetVisible(wndVehicle, false)
	showCursor(false)
end

function onPlayerSelectVehicle(button, state)
	if (button ~= "left" or state ~= "up") then return end
	if (guiGridListGetSelectedItem(gridVehicle) == -1) then return end
	local vrow = guiGridListGetSelectedItem(gridVehicle)
	local vname = guiGridListGetItemText(gridVehicle, vrow, vehicleColumn)
	local vid = getVehicleModelFromName(vname)
	guiSetVisible(wndVehicle, false)
	showCursor(false)
	triggerServerEvent("UIPjobvehicles.spawnJobVehicle", root, vid, v_table[1], v_table[2], v_table[3], v_table[4], v_table[5], v_table[6], v_table[7])
end