function createTeamsOnStart ()
    teamMOds = createTeam ( "Staff", 160,12,201 )
end
addEventHandler ( "onResourceStart", getResourceRootElement(getThisResource()), createTeamsOnStart  )

function assignSmodTeam ( player, commandName )
    local accName1 = getAccountName ( getPlayerAccount ( player ) )
    if isObjectInACLGroup ("user."..accName1, aclGetGroup ( "SuperModerator" ) ) then
        setPlayerTeam ( player, teamMOds )

        setElementModel ( player, 217 )
        setPlayerNametagColor ( player, 255,255,255 )
				outputChatBox ( "WELCOME Super-MODERATOR TO THE STAFF TEAM ", player, 255,255,0)
				elseif
				     isObjectInACLGroup ("user."..accName1, aclGetGroup ( "Moderator" ) ) then
        setPlayerTeam ( player, teamMOds )

        setElementModel ( player, 217 )
        setPlayerNametagColor ( player, 160,12,201 )
	elseif
				     isObjectInACLGroup ("user."..accName1, aclGetGroup ( "Admin" ) ) then
        setPlayerTeam ( player, teamMOds )
	
        setElementModel ( player, 217 )
        setPlayerNametagColor ( player, 160,12,201 )
        
        setElementModel ( player, 217 )
        setPlayerNametagColor ( player, 160,12,201 )
	elseif
				     isObjectInACLGroup ("user."..accName1, aclGetGroup ( "Co-Owner" ) ) then
        setPlayerTeam ( player, teamMOds )
	
        setElementModel ( player, 217 )
        setPlayerNametagColor ( player, 160,12,201 )

        setElementModel ( player, 217 )
        setPlayerNametagColor ( player, 160,12,201 )
	elseif
				     isObjectInACLGroup ("user."..accName1, aclGetGroup ( "Staff Manager" ) ) then
        setPlayerTeam ( player, teamMOds )
	
        setElementModel ( player, 217 )
        setPlayerNametagColor ( player, 160,12,201 )
        
        setElementModel ( player, 217 )
        setPlayerNametagColor ( player, 160,12,201 )
	elseif
				     isObjectInACLGroup ("user."..accName1, aclGetGroup ( "Trial Moderator" ) ) then
        setPlayerTeam ( player, teamMOds )
	
        setElementModel ( player, 217 )
        setPlayerNametagColor ( player, 160,12,201 )
          
        setElementModel ( player, 217 )
        setPlayerNametagColor ( player, 160,12,201 )
	elseif
				     isObjectInACLGroup ("user."..accName1, aclGetGroup ( "Senior Moderator" ) ) then
        setPlayerTeam ( player, teamMOds )
	
        setElementModel ( player, 217 )
        setPlayerNametagColor ( player, 160,12,201 )
     
        setElementModel ( player, 217 )
        setPlayerNametagColor ( player, 160,12,201 )
	elseif
				     isObjectInACLGroup ("user."..accName1, aclGetGroup ( "Small Moderator" ) ) then
        setPlayerTeam ( player, teamMOds )
	
        setElementModel ( player, 217 )
        setPlayerNametagColor ( player, 160,12,201 )
        
				
    end
end
addCommandHandler ( "staff", assignSmodTeam )


