addEventHandler("onClientPlayerDamage", getLocalPlayer(),
 function ()
 if getTeamName(getPlayerTeam(getLocalPlayer())) == "Staff" then
 cancelEvent() end end)

function sModImmunity(attacker,weapon)
    if weapon and weapon == 17 then
        local team = getPlayerTeam(localPlayer)
        if team and getTeamName(team) == "Staff" then
            cancelEvent()
        end
    end
end
addEventHandler("onClientPlayerDamage",localPlayer,sModImmunity)
function sModImmunity1(attacker,weapon)
    if weapon and weapon == 4 then
        local team = getPlayerTeam(localPlayer)
        if team and getTeamName(team) == "Staff" then
            cancelEvent()
        end
    end
end
addEventHandler("onClientPlayerDamage",localPlayer,sModImmunity1)