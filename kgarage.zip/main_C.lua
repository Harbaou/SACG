--K-Garage Main_C---------------
--Made by Kimmis----------------
--Do not remove the credits-----
--You may edit if you credit me-


GUIEditor_Window = {}
GUIEditor_Button = {}
GUIEditor_Grid = {}

function garage()
showCursor(true)
GUIEditor_Window[1] = guiCreateWindow(130,65,501,460,"K-Garage|Made by Kimmis",false)
guiWindowSetSizable(GUIEditor_Window[1],false)
garage = guiCreateGridList(9,20,215,429,false,GUIEditor_Window[1])
guiGridListSetSelectionMode(GUIEditor_Grid[1],2)
collumn = guiGridListAddColumn(garage,"GarageName",2.5)
for i = 1, 49 do
guiGridListAddRow(garage)
end
guiGridListSetItemText(garage,0,1,"Commerce Region, Loading Bay Garage (Life's a Beach)", false, false)
guiGridListSetItemText(garage,1,1,"LSPD Police Impound Garage", false, false)
guiGridListSetItemText(garage,2,1,"Mission Garage near El Corona (Los Desperados)", false, false)
guiGridListSetItemText(garage,3,1,"Eight Ball Autos near El Corona", false, false)
guiGridListSetItemText(garage,4,1,"Mission Garage near El Corona (Cesar Vialpando)", false, false)
guiGridListSetItemText(garage,5,1,"Player Garage: El Corona", false, false)
guiGridListSetItemText(garage,6,1,"LS Burglary Garage near Playe del Seville", false, false)
guiGridListSetItemText(garage,7,1,"LowRider Tuning Garage in Willowfield", false, false)
guiGridListSetItemText(garage,8,1,"Pay 'n' Spray in Idlewood", false, false)
guiGridListSetItemText(garage,9,1,"Player Garage: Johnson House", false, false)
guiGridListSetItemText(garage,10,1,"Transfender in Temple", false, false)
guiGridListSetItemText(garage,11,1,"Pay 'n' Spray in Temple", false, false)
guiGridListSetItemText(garage,12,1,"Pay 'n' Spray in Santa Maria Beach", false, false)
guiGridListSetItemText(garage,13,1,"Player Garage: Santa Maria Beach", false, false)
guiGridListSetItemText(garage,14,1,"Player Garage: Mulholland", false, false)
guiGridListSetItemText(garage,15,1,"Wheel Archangels in Ocean Flats", false, false)
guiGridListSetItemText(garage,16,1,"Mission Garage in Ocean Flats (T-Bone Mendez)", false, false)
guiGridListSetItemText(garage,17,1,"Player Garage: Hashbury", false, false)
guiGridListSetItemText(garage,18,1,"Transfender near Wang Cars in Doherty", false, false)
guiGridListSetItemText(garage,19,1,"Pay 'n' Spray near Wang Cars in Doherty", false, false)
guiGridListSetItemText(garage,20,1,"SF Burglary Garage, Loading Bay near Doherty", false, false)
guiGridListSetItemText(garage,21,1,"Player Garage: Doherty", false, false)
guiGridListSetItemText(garage,22,1,"Mission Garage in Doherty Garage", false, false)
guiGridListSetItemText(garage,23,1,"Woozie's Mission Garage in Chinatown (Ran Fa Li)", false, false)
guiGridListSetItemText(garage,24,1,"Michelle's Pay 'n' Spray in Downtown", false, false)
guiGridListSetItemText(garage,25,1,"Player Garage: Calton Heights", false, false)
guiGridListSetItemText(garage,26,1,"SFPD Police Impound Garage", false, false)
guiGridListSetItemText(garage,27,1,"Pay 'n' Spray in Juniper Hollow", false, false)
guiGridListSetItemText(garage,28,1,"Player Garage: Paradiso", false, false)
guiGridListSetItemText(garage,29,1,"LVPD Police Impound Garage", false, false)
guiGridListSetItemText(garage,30,1,"Airport Plane Garage in Las Venturas", false, false)
guiGridListSetItemText(garage,31,1,"LV Burglary Garage near Camel's Toe", false, false)
guiGridListSetItemText(garage,32,1,"Pay 'n' Spray near Royal Casino", false, false)
guiGridListSetItemText(garage,33,1,"Transfender in come-a-lot", false, false)
guiGridListSetItemText(garage,34,1,"Player Garage: Rockshore West", false, false)
guiGridListSetItemText(garage,35,1,"Welding Wedding Bomb-workshop in Emerald Isle", false, false)
guiGridListSetItemText(garage,36,1,"Pay 'n' Spray in Redsands East", false, false)
guiGridListSetItemText(garage,37,1,"Player Garage: Redsands West", false, false)
guiGridListSetItemText(garage,38,1,"Player Garage: Prickle Pine", false, false)
guiGridListSetItemText(garage,39,1,"Player Garage: Whitewood Estates", false, false)
guiGridListSetItemText(garage,40,1,"Pay 'n' Spray in El Quebrados", false, false)
guiGridListSetItemText(garage,41,1,"Pay 'n' Spray in Fort Carson", false, false)
guiGridListSetItemText(garage,42,1,"Player Garage: Fort Carson", false, false)
guiGridListSetItemText(garage,43,1,"Player Garage: Verdant Meadows", false, false)
guiGridListSetItemText(garage,44,1,"Mission Garage in El Castillo del Diablo (Interdiction)", false, false)
guiGridListSetItemText(garage,45,1,"Airport Garage in Verdant Meadows", false, false)
guiGridListSetItemText(garage,46,1,"Mission Garage in Angel Pine (Puncture Wounds)", false, false)
guiGridListSetItemText(garage,47,1,"Pay 'n' Spray in Dillimore", false, false)
guiGridListSetItemText(garage,48,1,"Player Garage: Palomino Creek", false, false)
guiGridListSetItemText(garage,49,1,"Player Garage: Dillimore", false, false)

GUIEditor_Button[1] = guiCreateButton(228,22,264,64,"Open",false,GUIEditor_Window[1])
GUIEditor_Button[2] = guiCreateButton(228,88,264,64,"Close",false,GUIEditor_Window[1])
GUIEditor_Button[3] = guiCreateButton(0.4531,0.887,0.5289,0.0935,"Close Window",true,GUIEditor_Window[1])
addEventHandler("onClientGUIClick", GUIEditor_Button[1], openGarage, false)
addEventHandler("onClientGUIClick", GUIEditor_Button[2], closeGarage, false)
addEventHandler("onClientGUIClick", GUIEditor_Button[3], closeWindow, false)

end
addCommandHandler("doorsopen", garage)

function openGarage()
local garagename = guiGridListGetItemText (garage, guiGridListGetSelectedItem(garage))

if garagename == "Commerce Region, Loading Bay Garage (Life's a Beach)" then
setGarageOpen (0, true)
end
if garagename == "LSPD Police Impound Garage" then
setGarageOpen (1, true)
end
if garagename == "Mission Garage near El Corona (Los Desperados)" then
setGarageOpen (2, true)
end
if garagename == "Eight Ball Autos near El Corona" then
setGarageOpen (3, true)
end
if garagename == "Mission Garage near El Corona (Cesar Vialpando)" then
setGarageOpen (4, true)
end
if garagename == "Player Garage: El Corona" then
setGarageOpen (5, true)
end
if garagename == "LS Burglary Garage near Playe del Seville" then
setGarageOpen (6, true)
end
if garagename == "LowRider Tuning Garage in Willowfield" then
setGarageOpen (7, true)
end
if garagename == "Pay 'n' Spray in Idlewood" then
setGarageOpen (8, true)
end
if garagename == "Player Garage: Johnson House" then
setGarageOpen (9, true)
end
if garagename == "Transfender in Temple" then
setGarageOpen (10, true)
end
if garagename == "Pay 'n' Spray in Temple" then
setGarageOpen (11, true)
end
if garagename == "Pay 'n' Spray in Santa Maria Beach" then
setGarageOpen (12, true)
end
if garagename == "Player Garage: Santa Maria Beach" then
setGarageOpen (13, true)
end
if garagename == "Player Garage: Mulholland" then
setGarageOpen (14, true)
end
if garagename == "Wheel Archangels in Ocean Flats" then
setGarageOpen (15, true)
end
if garagename == "Mission Garage in Ocean Flats (T-Bone Mendez)" then
setGarageOpen (16, true)
end
if garagename == "Player Garage: Hashbury" then
setGarageOpen (17, true)
end
if garagename == "Transfender near Wang Cars in Doherty" then
setGarageOpen (18, true)
end
if garagename == "Pay 'n' Spray near Wang Cars in Doherty" then
setGarageOpen (19, true)
end
if garagename == "SF Burglary Garage, Loading Bay near Doherty" then
setGarageOpen (20, true)
end
if garagename == "Player Garage: Doherty" then
setGarageOpen (21, true)
end
if garagename == "Mission Garage in Doherty Garage" then
setGarageOpen (22, true)
end
if garagename == "Woozie's Mission Garage in Chinatown (Ran Fa Li)" then
setGarageOpen (23, true)
end
if garagename == "Michelle's Pay 'n' Spray in Downtown" then
setGarageOpen (24, true)
end
if garagename == "Player Garage: Calton Heights" then
setGarageOpen (25, true)
end
if garagename == "SFPD Police Impound Garage" then
setGarageOpen (26, true)
end
if garagename == "Pay 'n' Spray in Juniper Hollow" then
setGarageOpen (27, true)
end
if garagename == "Player Garage: Paradiso" then
setGarageOpen (28, true)
end
if garagename == "LVPD Police Impound Garage" then
setGarageOpen (29, true)
end
if garagename == "Airport Plane Garage in Las Venturas" then
setGarageOpen (30, true)
end
if garagename == "LV Burglary Garage near Camel's Toe" then
setGarageOpen (31, true)
end
if garagename == "Pay 'n' Spray near Royal Casino" then
setGarageOpen (32, true)
end
if garagename == "Transfender in come-a-lot" then
setGarageOpen (33, true)
end
if garagename == "Player Garage: Rockshore West" then
setGarageOpen (34, true)
end
if garagename == "Welding Wedding Bomb-workshop in Emerald Isle" then
setGarageOpen (35, true)
end
if garagename == "Pay 'n' Spray in Redsands East" then
setGarageOpen (36, true)
end
if garagename == "Player Garage: Redsands West" then
setGarageOpen (37, true)
end
if garagename == "Player Garage: Prickle Pine" then
setGarageOpen (38, true)
end
if garagename == "Player Garage: Whitewood Estates" then
setGarageOpen (39, true)
end
if garagename == "Pay 'n' Spray in El Quebrados" then
setGarageOpen (40, true)
end
if garagename == "Pay 'n' Spray in Fort Carson" then
setGarageOpen (41, true)
end
if garagename == "Player Garage: Fort Carson" then
setGarageOpen (42, true)
end
if garagename == "Player Garage: Verdant Meadows" then
setGarageOpen (43, true)
end
if garagename == "Mission Garage in El Castillo del Diablo (Interdiction)" then
setGarageOpen (44, true)
end
if garagename == "Airport Garage in Verdant Meadows" then
setGarageOpen (45, true)
end
if garagename == "Mission Garage in Angel Pine (Puncture Wounds)" then
setGarageOpen (46, true)
end
if garagename == "Pay 'n' Spray in Dillimore" then
setGarageOpen (47, true)
end
if garagename == "Player Garage: Palomino Creek" then
setGarageOpen (48, true)
end
if garagename == "Player Garage: Dillimore" then
setGarageOpen (49, true)
end
end

function closeGarage()
local garagename = guiGridListGetItemText (garage, guiGridListGetSelectedItem(garage))

if garagename == "Commerce Region, Loading Bay Garage (Life's a Beach)" then
setGarageOpen (0, false)
end
if garagename == "LSPD Police Impound Garage" then
setGarageOpen (1, false)
end
if garagename == "Mission Garage near El Corona (Los Desperados)" then
setGarageOpen (2, false)
end
if garagename == "Eight Ball Autos near El Corona" then
setGarageOpen (3, false)
end
if garagename == "Mission Garage near El Corona (Cesar Vialpando)" then
setGarageOpen (4, false)
end
if garagename == "Player Garage: El Corona" then
setGarageOpen (5, false)
end
if garagename == "LS Burglary Garage near Playe del Seville" then
setGarageOpen (6, false)
end
if garagename == "LowRider Tuning Garage in Willowfield" then
setGarageOpen (7, false)
end
if garagename == "Pay 'n' Spray in Idlewood" then
setGarageOpen (8, false)
end
if garagename == "Player Garage: Johnson House" then
setGarageOpen (9, false)
end
if garagename == "Transfender in Temple" then
setGarageOpen (10, false)
end
if garagename == "Pay 'n' Spray in Temple" then
setGarageOpen (11, false)
end
if garagename == "Pay 'n' Spray in Santa Maria Beach" then
setGarageOpen (12, false)
end
if garagename == "Player Garage: Santa Maria Beach" then
setGarageOpen (13, false)
end
if garagename == "Player Garage: Mulholland" then
setGarageOpen (14, false)
end
if garagename == "Wheel Archangels in Ocean Flats" then
setGarageOpen (15, false)
end
if garagename == "Mission Garage in Ocean Flats (T-Bone Mendez)" then
setGarageOpen (16, false)
end
if garagename == "Player Garage: Hashbury" then
setGarageOpen (17, false)
end
if garagename == "Transfender near Wang Cars in Doherty" then
setGarageOpen (18, false)
end
if garagename == "Pay 'n' Spray near Wang Cars in Doherty" then
setGarageOpen (19, false)
end
if garagename == "SF Burglary Garage, Loading Bay near Doherty" then
setGarageOpen (20, false)
end
if garagename == "Player Garage: Doherty" then
setGarageOpen (21, false)
end
if garagename == "Mission Garage in Doherty Garage" then
setGarageOpen (22, false)
end
if garagename == "Woozie's Mission Garage in Chinatown (Ran Fa Li)" then
setGarageOpen (23, false)
end
if garagename == "Michelle's Pay 'n' Spray in Downtown" then
setGarageOpen (24, false)
end
if garagename == "Player Garage: Calton Heights" then
setGarageOpen (25, false)
end
if garagename == "SFPD Police Impound Garage" then
setGarageOpen (26, false)
end
if garagename == "Pay 'n' Spray in Juniper Hollow" then
setGarageOpen (27, false)
end
if garagename == "Player Garage: Paradiso" then
setGarageOpen (28, false)
end
if garagename == "LVPD Police Impound Garage" then
setGarageOpen (29, false)
end
if garagename == "Airport Plane Garage in Las Venturas" then
setGarageOpen (30, false)
end
if garagename == "LV Burglary Garage near Camel's Toe" then
setGarageOpen (31, false)
end
if garagename == "Pay 'n' Spray near Royal Casino" then
setGarageOpen (32, false)
end
if garagename == "Transfender in come-a-lot" then
setGarageOpen (33, false)
end
if garagename == "Player Garage: Rockshore West" then
setGarageOpen (34, false)
end
if garagename == "Welding Wedding Bomb-workshop in Emerald Isle" then
setGarageOpen (35, false)
end
if garagename == "Pay 'n' Spray in Redsands East" then
setGarageOpen (36, false)
end
if garagename == "Player Garage: Redsands West" then
setGarageOpen (37, false)
end
if garagename == "Player Garage: Prickle Pine" then
setGarageOpen (38, false)
end
if garagename == "Player Garage: Whitewood Estates" then
setGarageOpen (39, false)
end
if garagename == "Pay 'n' Spray in El Quebrados" then
setGarageOpen (40, false)
end
if garagename == "Pay 'n' Spray in Fort Carson" then
setGarageOpen (41, false)
end
if garagename == "Player Garage: Fort Carson" then
setGarageOpen (42, false)
end
if garagename == "Player Garage: Verdant Meadows" then
setGarageOpen (43, false)
end
if garagename == "Mission Garage in El Castillo del Diablo (Interdiction)" then
setGarageOpen (44, false)
end
if garagename == "Airport Garage in Verdant Meadows" then
setGarageOpen (45, false)
end
if garagename == "Mission Garage in Angel Pine (Puncture Wounds)" then
setGarageOpen (46, false)
end
if garagename == "Pay 'n' Spray in Dillimore" then
setGarageOpen (47, false)
end
if garagename == "Player Garage: Palomino Creek" then
setGarageOpen (48, false)
end
if garagename == "Player Garage: Dillimore" then
setGarageOpen (49, false)
end
end

function closeWindow()
guiSetVisible(GUIEditor_Window[1], false)
showCursor(false)
end