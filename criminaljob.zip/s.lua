function createSAPDTeam ()
    SAPDteam = createTeam ("Criminal", 255, 0, 0)
end

function joincriminal()
if isObjectInACLGroup("user."..getAccountName(getPlayerAccount(source)), aclGetGroup("Everyone")) then
local wlevel = getPlayerWantedLevel( source )
end
end
addEventHandler ("onResourceStart", resourceRoot, createSAPDTeam)
 
function joinSAPD()
     setPlayerTeam(source,SAPDteam)
     setElementFrozen ( ped, true )
     setElementHealth ( ped, 180 )
     giveWeapon ( source, 3 )
     giveWeapon ( source, 31,2500 )
     setElementData( source, "Occupation", "Government", true )
     setElementData ( source, "Rank", "Federal Agent" )
end
addCommandHandler("criminal",joinSAPD)
addEvent("gov", true)
addEventHandler("gov",root,joinSAPD)