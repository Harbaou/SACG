local marker = createMarker( 2000.763671875, 1539.0169677734, 13.5859375, "Cylinder", 1.5, 0, 0, 0, 10)
local ped = createPed          (21, 2000.6636962891, 1538.318359375, 13.5859375)
createBlip (2000.763671875, 1539.0169677734, 13.5859375, 23 ,2 )
                    myFont = dxCreateFont( "SF Automaton Bold.ttf", 20 )  -- Create custom font



GUIEditor_Button = {}
GUIEditor_Memo = {}
GUIEditor_gridlist = {}

        windowjob = guiCreateWindow(392, 176, 408, 437, "Criminal Job", false)
        guiWindowSetSizable(windowjob, false)
guiSetVisible(windowjob, false)
        GUIEditor_Memo[1] = guiCreateMemo(18, 30, 362, 221, "Hi,\nFeatures of Criminal job :\n-Turf with your Gang\n-\n-\nDo you want to join ?", false, windowjob)
        guiMemoSetReadOnly(GUIEditor_Memo[1], true)
        GUIEditor_gridlist[1] = guiCreateGridList(21, 264, 359, 115, false, windowjob)
        guiGridListAddColumn(GUIEditor_gridlist[1], "ID", 0.5)
        guiGridListAddColumn(GUIEditor_gridlist[1], "Skin Name", 0.5)
        for i = 1, 5 do
            guiGridListAddRow(GUIEditor_gridlist[1])
        end
        guiGridListSetItemText(GUIEditor_gridlist[1], 0, 1, "29", false, false)
        guiGridListSetItemText(GUIEditor_gridlist[1], 0, 2, "White Dealer", false, false)
        guiGridListSetItemText(GUIEditor_gridlist[1], 1, 1, "28", false, false)
        guiGridListSetItemText(GUIEditor_gridlist[1], 1, 2, "Black Dealer", false, false)
        GUIEditor_Button[1] = guiCreateButton(21, 379, 175, 48, "Take job !", false, windowjob)
        GUIEditor_Button[2] = guiCreateButton(206, 379, 174, 48, "Cancel", false, windowjob)
        
function SAPDjob(hitElement)
                setElementData ( localPlayer, "ownskin", getElementModel (localPlayer)  )
    if getElementType(hitElement) == "player" and (hitElement == localPlayer) then
    if not guiGetVisible(windowjob) then
        guiSetVisible(windowjob, true)
                      showCursor(true)
                  end
             end
        end
        addEventHandler("onClientMarkerHit", marker, SAPDjob)
         
        function FBIjobleave(leaveElement)
        
             if getElementType(leaveElement) == "player" and (leaveElement == localPlayer) then
                  if guiGetVisible(windowjob) then
                       guiSetVisible(windowjob, false)
                       showCursor(false)
                  end
             end
        end
        addEventHandler("onClientMarkerLeave", marker, SAPDjobleave)
        function setskintest()
        local skin = guiGridListGetItemText ( GUIEditor_gridlist[1], guiGridListGetSelectedItem ( GUIEditor_gridlist[1] ), 1 )
        setElementModel ( localPlayer, skin )
        end
             addEventHandler ( "onClientGUIClick", GUIEditor_gridlist[1], setskintest, false )
        function joinTeam()
             triggerServerEvent("gov",localPlayer)
             local skin = guiGridListGetItemText ( GUIEditor_gridlist[1], guiGridListGetSelectedItem ( GUIEditor_gridlist[1] ), 1 )
             if skin ~= 0 or getElementData(localPlayer, "ownskin") then
             guiSetVisible(windowjob, false)
             showCursor(false)
             setElementModel ( localPlayer, skin )
             else
             exports["TopBarChat"]:sendClientMessage ("You didn't select a Skin", 255, 0, 0 )
             
        end
        end
        addEventHandler("onClientGUIClick", GUIEditor_Button[1] , joinTeam, false)
         
        function removeSAPDWindow()
        guiSetVisible(windowjob, false)
        showCursor(false)
        setElementModel(localPlayer, getElementData(localPlayer, "ownskin"))
             
        end
        
        
        addEventHandler("onClientGUIClick", GUIEditor_Button[2] , removeSAPDWindow, false)

     local maxDistance = 12 -- the distance showing 3dtext
   local ped = createPed (21, 2000.6636962891, 1538.318359375, 13.5859375)
     
    addEventHandler ( "onClientRender", root,
        function ( )
     local pX, pY, pZ = getElementPosition ( localPlayer )
            local pedX, pedY, pedZ = getElementPosition ( ped )
            local distance = getDistanceBetweenPoints3D ( pX, pY, pZ, pedX, pedY, pedZ )
           
            if ( distance <= 12 ) then
                local x, y = getScreenFromWorldPosition ( pedX, pedY, pedZ )
                if ( x and y ) then
                dxDrawText( "Criminal", x, y+1.5, _, _, tocolor( 255, 0, 0, 255 ), 1, myFont, "center", "center" )
                end
            end
        end
    )