SWAT Officer
-------------------------------------------------------------
SWAT Officer
-------------------------------------------------------------
Installation instructions:
-------------------------------------------------------------
1) Author`s Email: oggy271@hotmail.com
Author: Valve, Oggy Livington
Was added to the site by user: GM-robot
Replace: swat (id285)
-------------------------------------------------------------
2) Importing files into the game archive:
With the IMGTool 2.0 or Crazy IMG Editor program import files from the folder "To import to gta3.img" in the archive [Game folder]\models\gta3.img

You can download IMGTool 2.0 here: http://www.gamemodding.net/gta-san-andreas/gta-sa-programms/829-imgtool-20.html
Crazy IMG Editor here:  http://www.gamemodding.net/gta-san-andreas/gta-sa-programms/828-gta-san-andreas-crazy-img-editor.html
-------------------------------------------------------------
This modification was downloaded from http://www.gamemodding.net website
Follow us in social networks!
http://vk.com/gamemoddingnet
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
