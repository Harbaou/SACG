SWAT Officer
-------------------------------------------------------------
SWAT Officer
-------------------------------------------------------------
Инструкция по установке:
-------------------------------------------------------------
1) Email автора: oggy271@hotmail.com
Автор: Valve, Oggy Livington
На сайт добавил пользователь: GM-robot
Заменяет: swat (id285)
-------------------------------------------------------------
2) Импорт файлов в IMG архив:
С помощью программы IMGTool 2.0 или Crazy IMG Editor импортируйте файлы из папки "To import to gta3.img" в архив [Папка с игрой]\models\gta3.img

IMGTool 2.0 Вы можете скачать тут: http://www.gamemodding.net/gta-san-andreas/gta-sa-programms/829-imgtool-20.html
Crazy IMG Editor тут: http://www.gamemodding.net/gta-san-andreas/gta-sa-programms/828-gta-san-andreas-crazy-img-editor.html
-------------------------------------------------------------
Эта модификация была скачана с сайта http://www.gamemodding.net
Присоединяйтесь к нам в социальных сетях!
http://vk.com/gamemoddingnet
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
