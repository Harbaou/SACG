SWAT Officer
-------------------------------------------------------------
SWAT Officer
-------------------------------------------------------------
Installation Anleitung:
-------------------------------------------------------------
1) Email des Autors: oggy271@hotmail.com
Der Autor: Valve, Oggy Livington
Auf der Site vom Benutzer hinzugefuegt wurde: GM-robot
Ersetzt: swat (id285)
-------------------------------------------------------------
2) Importieren von Dateien in das Spiel-Archiv:
Mit dem Programm IMGTool 2.0 oder Crazy IMG Editor importieren Sie Dateien aus einem Ordner "To import to gta3.img" im Archiv [Ordner mit dem Spiel]\models\gta3.img

Die Download-Link fuer IMGTool 2.0 ist hier: http://www.gamemodding.net/gta-san-andreas/gta-sa-programms/829-imgtool-20.html
Crazy IMG Editor hier: http://www.gamemodding.net/gta-san-andreas/gta-sa-programms/828-gta-san-andreas-crazy-img-editor.html
-------------------------------------------------------------
Diese Modifikation wurde von der Website http://www.gamemodding.net heruntergeladen\r\nFolgen Sie uns in den sozialen Netzwerken!
http://vk.com/gamemoddingnet
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
