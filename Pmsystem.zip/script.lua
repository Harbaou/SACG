local mycrpmpartner = {}

function thePM(thePlayer,commandName,sendToName,...)
	local pmWords = { ... }
	local pmMessage = table.concat( pmWords, " " )
	if sendToName then
		if getPlayerFromNamePart2(sendToName) then
		local toPlayer = getPlayerFromNamePart2(sendToName)
			if not (toPlayer == thePlayer) then --that () needed
				if not (pmMessage == "") then
					outputChatBox("#7575FF[PM] Message to #ff00ff" .. getPlayerName(toPlayer) .. ":#ffffff " .. pmMessage, thePlayer, 255, 255, 255, true)
					outputChatBox("#7575FF[PM] Message from #7575FF" .. getPlayerName(thePlayer) .. ":#7575FF " .. pmMessage, toPlayer, 255, 255, 255, true)
					mycrpmpartner[thePlayer]=toPlayer
					mycrpmpartner[toPlayer]=thePlayer
				else
					outputChatBox("E3DC14[PM]Use:#ff9900 /pm [part of name] [message]", thePlayer,227 , 227, 20, true)
				end
			else
				outputChatBox("#FF000[PM] You cannot PM yourself #ff9900!", thePlayer, 255, 255, 255, true)
			end
		else
			outputChatBox("#7575FF[PM] Player not found! #7575FF[#ff9900"..sendToName.."#7575FF]", thePlayer, 255, 255, 255, true)
		end
	else
		outputChatBox("#E3DC14[PM]Use:#E3DC14 /pm [part of name] [message]", thePlayer, 227, 227, 20, 255, true)
	end
end
addCommandHandler("pm", thePM)


function reply(thePlayer,commandName,...)
	local pmWords = { ... }
	local pmMessage = table.concat( pmWords, " " )
	local toPlayer = mycrpmpartner[thePlayer]
			if toPlayer and isElement(toPlayer) then 
				if not (pmMessage == "") then
					outputChatBox("#7575FF[PM] Message to #7575FF" .. getPlayerName(toPlayer) .. ":#7575FF " .. pmMessage, thePlayer, 255, 255, 255, true)
					outputChatBox("#7575FF[PM] Message from #ffFFff" .. getPlayerName(thePlayer) .. ":#ffffff " .. pmMessage, toPlayer, 255, 255, 255, true)
				else
					outputChatBox("#7575FF[PM]Use:#E3DC14 /r [message]", thePlayer, 227 , 227, 20, true)
				end
			else
				outputChatBox("#7575FF[PM]There is no pm partner", thePlayer, 255, 255, 255, true)
			end
end
addCommandHandler("r", reply)


function getPlayerFromNamePart2 ( name ) --MY EPIC PLAYER FIND PART :D
    if ( name ) then 
        for _, player in ipairs ( getElementsByType ( "player" ) ) do
			local name_ = getPlayerName ( player ):gsub ( "#%x%x%x%x%x%x", "" ):lower ( )
				if name_:find ( tostring ( name ):lower ( ), 1, true ) then
					return player 
				end
        end
    end
end

addEventHandler ( "onPlayerQuit", getRootElement(), function()
mycrpmpartner[source]=nil
end)
