function createTeamsOnStart ()
teamUnem = createTeam ( "Unemployed", 130, 123, 123 )
end
addEventHandler ( "onResourceStart", getResourceRootElement(getThisResource()), createTeamsOnStart )

function joinUnem()
	setPlayerTeam(source,teamUnem)
	setElementModel(source, 46)
	setCameraTarget(source,player)
	spawnPlayer ( source, 1545.69678, -1675.24231, 13.56087, 90 ) 
	setElementData ( source, "Rank", "None" )
	setElementData( source, "Occupation", "Unemployed", true )
end
addEventHandler("onPlayerLogin",getRootElement(),joinUnem)

addEvent("kick",true)
addEventHandler("kick", root, joinUnem)

function join(player)
	setPlayerTeam(player,teamUnem)
	setElementModel(player, 0)
	setCameraTarget(source,player)
	setElementData ( source, "Rank", "None" )
	outputChatBox("You resigned from your job.",player,255,0,0)
end
addCommandHandler("resign", join)
